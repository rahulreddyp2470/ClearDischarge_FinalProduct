"""
ClearDischarge — Stage 3: Patient Action Plan Generator
═══════════════════════════════════════════════════════
Generates a plain-language Patient Action Plan from
extracted data, drug interactions, and RAG context.

Integrates:
  - Prompt Engineering: structured generation prompt
  - RAG: patient education context from knowledge base
  - Fine-Tuning: readability classifier validation gate
"""

import os
import json
import textstat
from groq import Groq
from dotenv import load_dotenv

load_dotenv()
client = Groq(api_key=os.getenv("GROQ_API_KEY"))
MODEL = "llama-3.3-70b-versatile"

TARGET_GRADE = 8.0
MAX_RETRIES  = 2

# ── Prompt Engineering: generation system prompt ─────────────────────────────
SYSTEM_PROMPT = """You are a compassionate patient education specialist.
Your job is to turn structured medical discharge data into a warm, clear Patient Action Plan.

Rules:
1. Write at a Grade 7–8 reading level. Use short sentences. Use simple everyday words.
2. Never invent information not present in the data provided.
3. Never use medical jargon without immediately explaining it in plain English.
4. Be warm and reassuring — the patient may be scared or overwhelmed.
5. If patient education reference material is provided, incorporate relevant
   guidance naturally — but ONLY if it matches this patient's specific situation.
6. Structure your response EXACTLY with these section headers:
   ## 💊 Your Medications
   ## ⚠️ Drug Safety Alerts
   ## 🚫 Important Restrictions
   ## 🚨 Go to the ER Immediately If...
   ## 📅 Your Follow-Up Appointments
   ## ✅ Your Daily Checklist"""


def _build_prompt(extracted: dict, interactions: list,
                  rag_context: str = "", simplify: bool = False) -> str:
    """
    Build the generation prompt with all available context.
    Integrates extracted data, drug interaction alerts, and RAG context.
    """
    simplify_note = (
        "\n\nIMPORTANT: Your previous response was too complex. "
        "Rewrite using shorter sentences (max 15 words each) and simpler words. "
        "Avoid all medical terms. Write like you are talking to a friend.\n\n"
        if simplify else "\n\n"
    )

    if interactions:
        alerts = "\n".join(
            f"- {'🔴 HIGH RISK' if w['severity']=='HIGH' else '🟡 MODERATE'}: {w['message']} (Source: {w['source']})"
            for w in interactions
        )
        drug_section = f"DRUG INTERACTION ALERTS (include these in Drug Safety Alerts):\n{alerts}"
    else:
        drug_section = "DRUG INTERACTIONS: None detected. State this reassuringly."

    # RAG context section
    rag_section = ""
    if rag_context:
        rag_section = f"\n\n{rag_context}\n"

    return (
        f"{simplify_note}"
        f"Generate a Patient Action Plan from this discharge data.\n\n"
        f"EXTRACTED DATA:\n{json.dumps(extracted, indent=2)}\n\n"
        f"{drug_section}\n"
        f"{rag_section}\n"
        f"Write the complete Patient Action Plan now:"
    )


def generate(extracted: dict, interactions: list,
             rag_context: str = "", use_ml_readability: bool = True) -> dict:
    """
    Generate a plain-language Patient Action Plan with readability scoring.

    Uses a two-gate readability check:
      1. Flesch-Kincaid (formula-based)
      2. Fine-tuned DistilBERT classifier (if available)

    Retries with a "simplify" instruction if either gate fails.
    """
    # Try to load fine-tuned readability model
    ml_model, ml_tokenizer = None, None
    if use_ml_readability:
        try:
            from readability_model import load_classifier, predict_readability
            ml_model, ml_tokenizer = load_classifier()
        except (ImportError, Exception):
            pass

    retries  = 0
    simplify = False
    text     = ""
    grade    = 0.0
    readability_result = None

    for _ in range(MAX_RETRIES + 1):
        msg = client.chat.completions.create(
            model=MODEL,
            max_tokens=2048,
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": _build_prompt(extracted, interactions, rag_context, simplify)}
            ]
        )
        text  = msg.choices[0].message.content.strip()
        grade = textstat.flesch_kincaid_grade(text)

        # Gate 1: Flesch-Kincaid
        fk_pass = grade <= TARGET_GRADE

        # Gate 2: ML classifier (if available)
        ml_pass = True
        if ml_model is not None:
            readability_result = predict_readability(text, ml_model, ml_tokenizer)
            ml_pass = readability_result["label"] == "PASS"
        else:
            readability_result = {
                "label": "PASS" if fk_pass else "FAIL",
                "confidence": 1.0,
                "fk_grade": round(grade, 1),
                "model_used": False
            }

        if fk_pass and ml_pass:
            break
        retries += 1
        simplify = True

    return {
        "text":                text,
        "grade_level":         round(grade, 1),
        "retries_needed":      retries,
        "target_met":          grade <= TARGET_GRADE,
        "readability_check":   readability_result,
        "rag_context_used":    bool(rag_context),
    }


# ── Test block ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import pathlib
    from drug_checker import check_interactions

    p = pathlib.Path("last_extraction.json")
    if not p.exists():
        print("❌ Run extractor.py first to generate last_extraction.json")
        exit(1)

    extracted    = json.loads(p.read_text())
    interactions = check_interactions(extracted.get("medications", []))

    # Try RAG retrieval
    rag_context = ""
    try:
        from rag_knowledge import retrieve, format_rag_context
        diagnosis = extracted.get("primary_diagnosis", "")
        med_names = [m["name"] for m in extracted.get("medications", [])]
        retrieved = retrieve("patient education", diagnosis=diagnosis,
                             medications=med_names)
        rag_context = format_rag_context(retrieved)
        print(f"📚 RAG: Retrieved {len(retrieved)} education chunks")
    except Exception as e:
        print(f"⚠️  RAG unavailable: {e}")

    print(f"Found {len(interactions)} interaction(s). Generating report...\n")
    result = generate(extracted, interactions, rag_context=rag_context)

    print("═" * 60)
    print(result["text"])
    print("═" * 60)
    print(f"\n📊 Reading Grade : {result['grade_level']} (target ≤ {TARGET_GRADE})")
    print(f"🔁 Retries       : {result['retries_needed']}")
    print(f"✅ Target Met    : {result['target_met']}")
    print(f"📚 RAG Used      : {result['rag_context_used']}")
    if result.get("readability_check"):
        rc = result["readability_check"]
        print(f"🤖 ML Readability: {rc['label']} (confidence: {rc['confidence']:.0%}, model: {rc['model_used']})")
