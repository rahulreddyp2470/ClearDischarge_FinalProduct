"""
ClearDischarge Evaluation Harness
──────────────────────────────────
Supports three data sources:
  --sample     → 5 built-in cases (no API needed for data)
  --synthetic  → Generate N diverse cases via Claude (Component 4)
  --mimic      → Load from MIMIC-III NOTEEVENTS.csv (PhysioNet)

Evaluates the full pipeline: extraction → drug check → RAG → generation
Reports: recall, hallucination rate, readability, RAG usage, ML readability
"""

import json
import argparse
import textstat
from extractor    import extract
from drug_checker import check_interactions
from generator    import generate


# ── Scoring helpers ──────────────────────────────────────────────────────────
def _recall(extracted: list[str], ground_truth: list[str]) -> float:
    """What fraction of ground truth items did we correctly find?"""
    if not ground_truth:
        return 1.0
    gt_lower  = [g.lower() for g in ground_truth]
    ext_lower = [e.lower() for e in extracted]
    hits = sum(
        any(gt in ext or ext in gt for ext in ext_lower)
        for gt in gt_lower
    )
    return round(hits / len(gt_lower), 3)


def _hallucination_rate(extracted_meds: list[str], source_text: str) -> float:
    """What fraction of extracted drug names don't appear in the source?"""
    if not extracted_meds:
        return 0.0
    source_lower = source_text.lower()
    hallucinated = [
        m for m in extracted_meds
        if m.lower().split("(")[0].strip() not in source_lower
    ]
    return round(len(hallucinated) / len(extracted_meds), 3)


def _load_mimic(n_samples: int = 10) -> list[dict]:
    """Load discharge summaries from MIMIC-III NOTEEVENTS.csv"""
    import pandas as pd, pathlib
    csv_path = pathlib.Path("NOTEEVENTS.csv")
    if not csv_path.exists():
        raise FileNotFoundError(
            "NOTEEVENTS.csv not found.\n"
            "Download from https://physionet.org/content/mimiciii/\n"
            "Or use --sample or --synthetic flags."
        )
    df = pd.read_csv(csv_path, low_memory=False)
    discharges = df[df["CATEGORY"] == "Discharge summary"].dropna(subset=["TEXT"])
    samples    = discharges.sample(n=n_samples, random_state=42)
    return [
        {"id": str(row.get("ROW_ID", "unknown")),
         "text": row["TEXT"], "ground_truth": None}
        for _, row in samples.iterrows()
    ]


# ── Main evaluation loop ────────────────────────────────────────────────────
def run_evaluation(cases: list[dict], use_ground_truth: bool = True):
    results = []
    print(f"\nRunning evaluation on {len(cases)} cases...\n")

    # Try to initialize RAG
    rag_available = False
    try:
        from rag_knowledge import retrieve, format_rag_context, build_knowledge_base
        build_knowledge_base()
        rag_available = True
        print("📚 RAG knowledge base: ACTIVE")
    except Exception as e:
        print(f"⚠️  RAG unavailable: {e}")

    # Try to load ML readability model
    ml_available = False
    try:
        from readability_model import load_classifier
        model, tokenizer = load_classifier()
        ml_available = model is not None
        if ml_available:
            print("🤖 ML readability model: ACTIVE")
    except Exception:
        pass

    print()

    for i, case in enumerate(cases):
        case_id   = case.get("id", f"case_{i+1}")
        case_text = case.get("text") or case.get("discharge_text", "")
        print(f"  [{i+1}/{len(cases)}] Processing {case_id}...")

        # ── Full pipeline ────────────────────────────────────────────────
        extracted    = extract(case_text)
        interactions = check_interactions(extracted.get("medications", []))

        # RAG retrieval
        rag_context = ""
        if rag_available:
            try:
                diagnosis = extracted.get("primary_diagnosis", "")
                med_names = [m["name"] for m in extracted.get("medications", [])]
                retrieved = retrieve("patient education", diagnosis=diagnosis,
                                     medications=med_names)
                rag_context = format_rag_context(retrieved)
            except Exception:
                pass

        report = generate(extracted, interactions, rag_context=rag_context)

        ext_med_names = [m["name"] for m in extracted.get("medications", [])]
        grade         = report["grade_level"]
        halluc_rate   = _hallucination_rate(ext_med_names, case_text)

        result = {
            "id":                 case_id,
            "meds_extracted":     len(ext_med_names),
            "interactions":       len(interactions),
            "grade_level":        grade,
            "grade_target_met":   grade <= 8.0,
            "hallucination_rate": halluc_rate,
            "retries":            report["retries_needed"],
            "rag_used":           report["rag_context_used"],
            "ml_readability":     report.get("readability_check", {}).get("model_used", False),
        }

        # Score recall if ground truth is available
        gt = case.get("ground_truth")
        if use_ground_truth and gt:
            result["med_recall"]   = _recall(ext_med_names, gt["medications"])
            result["restr_recall"] = _recall(
                extracted.get("restrictions", []), gt["restrictions"]
            )
            result["flag_recall"] = _recall(
                extracted.get("red_flag_symptoms", []), gt["red_flags"]
            )
        results.append(result)

    return results


def print_report(results: list[dict], use_ground_truth: bool = True):
    n = len(results)
    avg = lambda key: round(sum(r.get(key, 0) for r in results) / n, 3)

    print("\n" + "═" * 65)
    print(f"  CLEARDISCHARGE EVALUATION RESULTS  (n={n} cases)")
    print("═" * 65)

    if use_ground_truth and "med_recall" in results[0]:
        med_recall   = avg("med_recall")
        restr_recall = avg("restr_recall")
        flag_recall  = avg("flag_recall")
        print(f"\n  Medication Recall        : {med_recall:.3f}  (target ≥ 0.95)  {'✅' if med_recall  >= 0.95 else '❌'}")
        print(f"  Restriction Recall       : {restr_recall:.3f}  (target ≥ 0.90)  {'✅' if restr_recall >= 0.90 else '❌'}")
        print(f"  Red Flag Recall          : {flag_recall:.3f}  (target ≥ 0.90)  {'✅' if flag_recall  >= 0.90 else '❌'}")

    halluc = avg("hallucination_rate")
    grade  = avg("grade_level")
    pct_grade  = sum(1 for r in results if r["grade_target_met"]) / n
    pct_rag    = sum(1 for r in results if r["rag_used"]) / n
    pct_ml     = sum(1 for r in results if r["ml_readability"]) / n

    print(f"\n  Hallucination Rate       : {halluc:.3f}  (target = 0.00)   {'✅' if halluc == 0.0 else '❌'}")
    print(f"  Avg Reading Grade Level  : {grade:.1f}   (target ≤ 8.0)    {'✅' if grade <= 8.0 else '❌'}")
    print(f"  % Cases Meeting Grade    : {pct_grade*100:.0f}%")
    print(f"  Avg Simplification Retries: {avg('retries'):.1f}")
    print(f"  Total Drug Interactions  : {sum(r['interactions'] for r in results)}")
    print(f"\n  ── Component Usage ──")
    print(f"  RAG Context Used         : {pct_rag*100:.0f}% of cases")
    print(f"  ML Readability Model     : {pct_ml*100:.0f}% of cases")

    print("\n" + "─" * 65)
    print("  PER-CASE BREAKDOWN")
    print("─" * 65)
    header = f"  {'ID':<15} {'Meds':>5} {'Halluc':>8} {'Grade':>7} {'RAG':>5} {'Retries':>8}"
    if use_ground_truth and "med_recall" in results[0]:
        header += f" {'MedRec':>8}"
    print(header)
    print("  " + "─" * 60)
    for r in results:
        rag_icon = "✓" if r["rag_used"] else "—"
        row = (f"  {r['id']:<15} {r['meds_extracted']:>5} "
               f"{r['hallucination_rate']:>8.2f} {r['grade_level']:>7.1f} "
               f"{rag_icon:>5} {r['retries']:>8}")
        if use_ground_truth and "med_recall" in r:
            row += f" {r['med_recall']:>8.3f}"
        print(row)

    print("\n" + "═" * 65)

    with open("evaluation_results.json", "w") as f:
        json.dump(results, f, indent=2)
    print("\n✅ Full results saved to evaluation_results.json")


# ── Entry point ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="ClearDischarge Evaluation Harness")
    parser.add_argument("--sample", action="store_true",
                        help="Use 5 built-in sample cases")
    parser.add_argument("--synthetic", action="store_true",
                        help="Generate synthetic test cases via Claude (Component 4)")
    parser.add_argument("--n", type=int, default=10,
                        help="Number of cases (for --synthetic or MIMIC-III)")
    args = parser.parse_args()

    if args.sample:
        print("Using built-in sample cases...\n")
        from synthetic_gen import BUILTIN_SAMPLES
        cases = []
        for s in BUILTIN_SAMPLES:
            cases.append({
                "id":           s["id"],
                "text":         s["discharge_text"],
                "ground_truth": s["ground_truth"]
            })
        use_gt = True

    elif args.synthetic:
        print(f"Generating {args.n} synthetic cases (Component 4)...\n")
        from synthetic_gen import generate_test_suite
        raw_cases = generate_test_suite(n_cases=args.n, balanced=True)
        cases = []
        for s in raw_cases:
            cases.append({
                "id":           s["id"],
                "text":         s["discharge_text"],
                "ground_truth": s["ground_truth"]
            })
        use_gt = True

    else:
        cases  = _load_mimic(n_samples=args.n)
        use_gt = False
        print("Note: Recall metrics skipped for MIMIC-III (no ground truth).\n")

    results = run_evaluation(cases, use_gt)
    print_report(results, use_gt)
