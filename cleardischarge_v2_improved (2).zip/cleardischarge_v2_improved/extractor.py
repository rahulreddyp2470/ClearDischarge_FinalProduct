"""
ClearDischarge — Stage 1: Clinical Data Extraction
═══════════════════════════════════════════════════
Component: PROMPT ENGINEERING
Extracts structured data from discharge summaries using
carefully engineered prompts with JSON schema enforcement.
"""

import os
import json
from groq import Groq
from dotenv import load_dotenv

load_dotenv()
client = Groq(api_key=os.getenv("GROQ_API_KEY"))
MODEL = "llama-3.3-70b-versatile"

# ── JSON Schema for structured extraction ────────────────────────────────────
SCHEMA = {
    "type": "object",
    "properties": {
        "medications": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "name":      {"type": "string"},
                    "dose":      {"type": "string"},
                    "frequency": {"type": "string"},
                    "with_food": {"type": "boolean"},
                    "notes":     {"type": "string"}
                },
                "required": ["name", "dose", "frequency"]
            }
        },
        "restrictions":           {"type": "array", "items": {"type": "string"}},
        "red_flag_symptoms":      {"type": "array", "items": {"type": "string"}},
        "followup_appointments": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "provider": {"type": "string"},
                    "within":   {"type": "string"},
                    "notes":    {"type": "string"}
                },
                "required": ["provider", "within"]
            }
        },
        "primary_diagnosis": {"type": "string"},
        "discharge_date":    {"type": "string"}
    },
    "required": ["medications", "restrictions", "red_flag_symptoms", "followup_appointments"]
}

# ── Prompt Engineering: System prompt with explicit rules ────────────────────
SYSTEM_PROMPT = """You are a clinical data extraction specialist.
Your ONLY job is to extract structured information from hospital discharge summaries.

Rules:
1. Extract EVERY medication — do not skip any, even if mentioned only once.
2. Normalize drug names to their generic name if possible (e.g. "Tylenol" → "Acetaminophen (Tylenol)").
3. If a field is not mentioned in the document, return an empty array [] — never guess or invent.
4. For with_food: return true if the document says "take with food/meals", false otherwise.
5. Return ONLY valid JSON — no explanation, no markdown, no code fences, no extra text.
6. Extract the primary diagnosis exactly as stated in the document.
7. For follow-up appointments, capture the provider type and timeframe precisely.
8. For red flag symptoms, extract ALL warning signs including specific thresholds (e.g., "fever above 101F")."""


def extract(discharge_text: str) -> dict:
    """Extract structured clinical data from a discharge summary."""
    msg = client.chat.completions.create(
        model=MODEL,
        max_tokens=2048,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": (
                f"Extract all clinical information from this discharge summary.\n\n"
                f"DISCHARGE SUMMARY:\n{discharge_text}\n\n"
                f"Return JSON matching this schema:\n{json.dumps(SCHEMA, indent=2)}\n\n"
                f"Return ONLY the JSON object. No markdown. No explanation."
            )}
        ]
    )
    raw = msg.choices[0].message.content.strip()
    # Strip markdown fences if Claude adds them
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    return json.loads(raw.strip())


def validate(data: dict) -> list:
    """Return warnings if required fields are empty."""
    warnings = []
    if not data.get("medications"):
        warnings.append("⚠️ No medications extracted — verify the source document.")
    if not data.get("red_flag_symptoms"):
        warnings.append("⚠️ No red-flag symptoms found — may be missing from document.")
    if not data.get("followup_appointments"):
        warnings.append("⚠️ No follow-up appointments found — verify with care team.")
    return warnings


def pretty_print(data: dict):
    print("\n" + "═" * 60)
    print("  EXTRACTION RESULTS")
    print("═" * 60)
    print(f"\n📋 Primary Diagnosis: {data.get('primary_diagnosis', 'Not specified')}")
    print(f"\n💊 Medications ({len(data.get('medications', []))}):")
    for m in data.get("medications", []):
        food  = " [take with food]" if m.get("with_food") else ""
        notes = f" — {m['notes']}" if m.get("notes") else ""
        print(f"   • {m['name']} {m['dose']} | {m['frequency']}{food}{notes}")
    print(f"\n🚫 Restrictions ({len(data.get('restrictions', []))}):")
    for r in data.get("restrictions", []):
        print(f"   • {r}")
    print(f"\n🚨 Red Flag Symptoms ({len(data.get('red_flag_symptoms', []))}):")
    for s in data.get("red_flag_symptoms", []):
        print(f"   • {s}")
    print(f"\n📅 Follow-up Appointments ({len(data.get('followup_appointments', []))}):")
    for f in data.get("followup_appointments", []):
        notes = f" — {f['notes']}" if f.get("notes") else ""
        print(f"   • {f['provider']} within {f['within']}{notes}")
    for w in validate(data):
        print(f"\n  {w}")
    print("\n" + "═" * 60 + "\n")


# ── Test block ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    SAMPLE = """
    PATIENT DISCHARGE SUMMARY
    Discharge Date: 2024-01-15
    PRIMARY DIAGNOSIS: Congestive Heart Failure (CHF), acute exacerbation

    MEDICATIONS AT DISCHARGE:
    1. Furosemide (Lasix) 40mg — take orally once daily in the morning
    2. Lisinopril 10mg — take orally once daily, take with food
    3. Carvedilol 6.25mg — take orally twice daily with meals
    4. Warfarin 5mg — take orally once daily, INR monitoring required
    5. Potassium Chloride 20mEq — take orally twice daily with food
    6. Aspirin 81mg — take orally once daily

    ACTIVITY RESTRICTIONS:
    - No strenuous physical activity for 2 weeks
    - Fluid restriction: no more than 1.5 liters per day
    - Low-sodium diet (less than 2g sodium per day)
    - Daily weight monitoring — weigh yourself each morning

    RETURN TO ER IMMEDIATELY IF:
    - Weight gain of more than 2 pounds in one day
    - Increased shortness of breath
    - Chest pain or pressure
    - Swelling in legs or ankles getting worse
    - Dizziness or fainting

    FOLLOW-UP APPOINTMENTS:
    - Primary Care Physician: within 7 days
    - Cardiologist: within 2 weeks
    - INR/Coumadin clinic: within 3 days for Warfarin monitoring
    """
    print("Running extraction...")
    result = extract(SAMPLE)
    pretty_print(result)
    with open("last_extraction.json", "w") as fp:
        json.dump(result, fp, indent=2)
    print("✅ Saved to last_extraction.json")
