"""
ClearDischarge — Streamlit Web Application
══════════════════════════════════════════
Integrates all 5 core components:
  1. Prompt Engineering  → extractor.py, generator.py
  2. RAG                 → rag_knowledge.py
  3. Multimodal          → multimodal.py (OCR + visual schedule)
  4. Synthetic Data Gen  → synthetic_gen.py (built-in test cases)
  5. Fine-Tuning         → readability_model.py (readability gate)
"""

import streamlit as st
import pypdf
import io
import os
import json
import tempfile
import time

from extractor    import extract, validate
from drug_checker import check_interactions
from generator    import generate

# ── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(page_title="ClearDischarge", page_icon="🏥", layout="wide")

# ── Accessibility Sidebar ─────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### ♿ Accessibility Settings")
    font_size = st.radio(
        "Text Size",
        ["Normal", "Large", "Extra Large"],
        index=0,
        help="Adjust the text size for easier reading.",
        captions=[
            "Best for long reports (500+ words)",
            "Best for medium reports (200–500 words)",
            "Best for short reports (under 200 words)"
        ]
    )
    high_contrast = st.toggle(
        "High Contrast Mode",
        value=False,
        help="Forces black background with white text for maximum visibility."
    )
    st.divider()
    st.caption(
        "ClearDischarge supports adjustable text size and high-contrast "
        "mode for low-vision users. All custom UI elements include "
        "descriptive labels for screen reader compatibility."
    )

# Map font size selection to CSS values
FONT_SIZES = {
    "Normal":      "16px",
    "Large":       "20px",
    "Extra Large": "24px"
}
body_font = FONT_SIZES[font_size]

# ── Styles ────────────────────────────────────────────────────────────────────
# Normal mode: dark-themed boxes that match Streamlit dark mode
# High contrast mode: maximum-contrast black/white scheme
if high_contrast:
    warn_bg,   warn_text   = "#3d3000", "#ffffff"
    danger_bg, danger_text = "#3d0000", "#ffffff"
    ok_bg,     ok_text     = "#003d00", "#ffffff"
    time_bg,   time_text   = "#1a1a2e", "#ffffff"
    link_color             = "#66b3ff"
    danger_link            = "#ff6666"
else:
    # Dark-friendly: muted backgrounds with light text (works in both themes)
    warn_bg,   warn_text   = "#432f00", "#fef3c7"
    danger_bg, danger_text = "#4a1111", "#fee2e2"
    ok_bg,     ok_text     = "#0f3d1a", "#dcfce7"
    time_bg,   time_text   = "#1e293b", "#e2e8f0"
    link_color             = "#fbbf24"
    danger_link            = "#f87171"

hc_css = ""
if high_contrast:
    hc_css = """
    /* Override Streamlit's own CSS variables — this is the only reliable way */
    .stApp, .stApp > header, [data-testid="stAppViewContainer"],
    [data-testid="stHeader"], section[data-testid="stSidebar"] {
        --background-color: #000000 !important;
        --secondary-background-color: #111111 !important;
        --text-color: #ffffff !important;
        background-color: #000000 !important;
        color: #ffffff !important;
    }
    [data-testid="stSidebar"], [data-testid="stSidebar"] > div {
        background-color: #111111 !important;
    }
    [data-testid="stSidebar"] p,
    [data-testid="stSidebar"] label,
    [data-testid="stSidebar"] span,
    [data-testid="stSidebar"] div {
        color: #ffffff !important;
    }
    .stMarkdown p, .stMarkdown li, .stMarkdown span,
    .stMarkdown h1, .stMarkdown h2, .stMarkdown h3, .stMarkdown h4,
    .stAlert p, label, .stRadio label, .stTextArea label,
    [data-testid="stMetric"] label, [data-testid="stMetric"] div,
    .stTabs button, .stExpander summary span {
        color: #ffffff !important;
    }
    .stCaption, .stCaption p { color: #ffffff !important; }
    .stTextInput input, .stTextArea textarea {
        background-color: #1a1a1a !important;
        color: #ffffff !important;
    }
    """

st.markdown(f"""
<style>
    {hc_css}
    .stTextArea textarea {{ font-family: monospace; font-size: {body_font}; }}
    .stMarkdown p, .stMarkdown li {{ font-size: {body_font}; }}
    {"" if high_contrast else ".stCaption, .stCaption p { color: #FFDB58; }"}
    .warning-box {{
        background: {warn_bg}; border-radius: 8px;
        padding: 0.8rem; border-left: 4px solid #f59e0b;
        margin: 0.4rem 0; color: {warn_text};
    }}
    .warning-box a {{ color: {link_color}; }}
    .danger-box {{
        background: {danger_bg}; border-radius: 8px;
        padding: 0.8rem; border-left: 4px solid #ef4444;
        margin: 0.4rem 0; color: {danger_text};
    }}
    .danger-box a {{ color: {danger_link}; }}
    .success-box {{
        background: {ok_bg}; border-radius: 8px;
        padding: 0.8rem; border-left: 4px solid #22c55e;
        margin: 0.4rem 0; color: {ok_text};
    }}
    .component-badge {{
        display: inline-block; padding: 2px 10px; border-radius: 12px;
        font-size: 0.75rem; font-weight: 600; margin-right: 4px;
    }}
    .badge-prompt  {{ background: #1e3a5f; color: #93c5fd; }}
    .badge-rag     {{ background: #14532d; color: #86efac; }}
    .badge-multi   {{ background: #451a03; color: #fde68a; }}
    .badge-synth   {{ background: #3b0764; color: #d8b4fe; }}
    .badge-finetune{{ background: #500724; color: #f9a8d4; }}
    .timing-box {{
        background: {time_bg}; border-radius: 8px;
        padding: 0.8rem; margin: 0.4rem 0; color: {time_text};
        font-family: monospace; font-size: 0.85rem;
    }}
</style>
""", unsafe_allow_html=True)

# ── Header ───────────────────────────────────────────────────────────────────
st.title("🏥 ClearDischarge")
st.subheader("Turn your hospital discharge paperwork into a clear, personal action plan")
st.caption("Powered by LLaMA 3.3 70B (Groq) + FDA Drug Safety Database + RAG Knowledge Base")

# Component badges
st.markdown(
    '<span class="component-badge badge-prompt">Prompt Engineering</span>'
    '<span class="component-badge badge-rag">RAG</span>'
    '<span class="component-badge badge-multi">Multimodal</span>'
    '<span class="component-badge badge-synth">Synthetic Data</span>'
    '<span class="component-badge badge-finetune">Fine-Tuning</span>',
    unsafe_allow_html=True
)

# ── User Onboarding ──────────────────────────────────────────────────────────
with st.expander("ℹ️ How to use ClearDischarge — First time? Start here", expanded=False):
    st.markdown("""
**Welcome!** ClearDischarge turns confusing hospital paperwork into a clear action plan you can actually follow.

**Step 1 — Get your paperwork.** Find the discharge summary from your hospital visit. It's the document listing your medications, restrictions, and follow-up appointments.

**Step 2 — Paste or upload.** Copy the text and paste it in the **Paste Text** tab, or upload the PDF in the **Upload PDF** tab. You can also click **Load Sample** to try a demo case.

**Step 3 — Click "Analyze My Discharge."** The system will extract your medications, check for drug interactions against the FDA database, and write a plain-language action plan at a reading level anyone can understand.

**Step 4 — Review your results.** Pay special attention to any **drug interaction alerts** (red or yellow boxes). Download your action plan and visual medication schedule to keep with you.

**Need larger text?** Use the accessibility settings in the left sidebar to increase text size or enable high-contrast mode.
    """)

st.warning(
    "⚕️ **Medical Disclaimer:** This tool is for informational purposes only. "
    "It is not a substitute for advice from your doctor, nurse, or pharmacist. "
    "Always follow the instructions given to you by your healthcare team.",
    icon="⚠️"
)
st.divider()


# ── Helper: PDF text extraction (text-based + OCR fallback) ──────────────────
def extract_pdf_text(uploaded_file) -> tuple[str, bool]:
    """
    Extract text from PDF. Tries text extraction first,
    falls back to OCR for scanned documents.
    Returns (text, used_ocr).
    """
    pdf_bytes = uploaded_file.read()

    # Try standard text extraction
    reader = pypdf.PdfReader(io.BytesIO(pdf_bytes))
    text = "\n".join(page.extract_text() or "" for page in reader.pages)

    if text.strip() and len(text.strip()) > 50:
        return text, False

    # Fallback: OCR for scanned PDFs (Multimodal Component)
    try:
        from multimodal import extract_text_ocr, is_scanned_pdf
        if is_scanned_pdf(pdf_bytes):
            ocr_text = extract_text_ocr(pdf_bytes)
            if ocr_text and not ocr_text.startswith("["):
                return ocr_text, True
    except ImportError:
        pass

    return text, False


# ── Sample discharge summary ─────────────────────────────────────────────────
SAMPLE = """PATIENT DISCHARGE SUMMARY
Discharge Date: 2024-01-15

PRIMARY DIAGNOSIS: Congestive Heart Failure (CHF), acute exacerbation

MEDICATIONS AT DISCHARGE:
1. Furosemide (Lasix) 40mg — take orally once daily in the morning
2. Lisinopril 10mg — take orally once daily, take with food
3. Carvedilol 6.25mg — take orally twice daily with meals
4. Warfarin 5mg — take orally once daily, INR monitoring required
5. Potassium Chloride 20mEq — take orally twice daily with food
6. Aspirin 81mg — take orally once daily

ACTIVITY RESTRICTIONS:
- No strenuous physical activity for 2 weeks
- Fluid restriction: no more than 1.5 liters per day
- Low-sodium diet (less than 2g sodium per day)
- Daily weight monitoring — weigh yourself each morning

RETURN TO EMERGENCY DEPARTMENT IMMEDIATELY IF:
- Weight gain of more than 2 pounds in one day
- Increased shortness of breath
- Chest pain or pressure
- Swelling in legs or ankles getting worse
- Dizziness or fainting

FOLLOW-UP APPOINTMENTS:
- Primary Care Physician: within 7 days
- Cardiologist: within 2 weeks
- INR/Coumadin clinic: within 3 days for Warfarin monitoring"""

# ── Session state ────────────────────────────────────────────────────────────
if "load_sample" not in st.session_state:
    st.session_state.load_sample = False
if "discharge_text" not in st.session_state:
    st.session_state.discharge_text = ""
# Analysis results persist across reruns (toggle, download, etc.)
if "results" not in st.session_state:
    st.session_state.results = None
if "pdf_text" not in st.session_state:
    st.session_state.pdf_text = None
if "pdf_name" not in st.session_state:
    st.session_state.pdf_name = None

# ── Input ────────────────────────────────────────────────────────────────────
st.markdown("### 📋 Choose Your Input Method")
tab1, tab2 = st.tabs(["📝 Paste Text", "📄 Upload PDF"])

discharge_input = ""

with tab1:
    st.caption("Copy the text from your discharge paperwork and paste it into the box.")

    if st.button("📄 Load Sample", use_container_width=False):
        st.session_state.discharge_text = SAMPLE
        st.rerun()

    typed = st.text_area(
        label="Discharge Summary Text",
        value=st.session_state.discharge_text,
        placeholder="Paste your discharge summary here...",
        height=300,
        help="Copy and paste the text exactly as it appears on your paperwork."
    )
    if typed != SAMPLE:
        st.session_state.discharge_text = typed
    discharge_input = st.session_state.discharge_text

with tab2:
    st.caption("Upload a discharge summary PDF. Text will be extracted automatically.")
    st.markdown(
        '<span class="component-badge badge-multi">Multimodal: OCR for scanned PDFs</span>',
        unsafe_allow_html=True
    )
    uploaded = st.file_uploader("Choose a PDF file", type=["pdf"])
    if uploaded:
        # Only re-process if it's a new file (different name)
        if st.session_state.pdf_name != uploaded.name:
            with st.spinner("Extracting text from PDF..."):
                pdf_text, used_ocr = extract_pdf_text(uploaded)
            if pdf_text.strip():
                st.session_state.pdf_text = pdf_text
                st.session_state.pdf_name = uploaded.name
                st.session_state.pdf_ocr  = used_ocr
            else:
                st.session_state.pdf_text = None
                st.session_state.pdf_name = None

        # Display cached result
        if st.session_state.pdf_text:
            method = "OCR (scanned document detected)" if st.session_state.get("pdf_ocr") else "text extraction"
            st.success(f"✅ PDF text extracted via {method} — {len(st.session_state.pdf_text.split())} words found.")
            with st.expander("Preview extracted text"):
                st.text(st.session_state.pdf_text[:1500] + ("..." if len(st.session_state.pdf_text) > 1500 else ""))
            discharge_input = st.session_state.pdf_text
        else:
            st.error("❌ Could not extract text. Try a different PDF or paste the text manually.")
    else:
        # File was removed — clear cached PDF data
        if st.session_state.pdf_name:
            st.session_state.pdf_text = None
            st.session_state.pdf_name = None

col1, col2 = st.columns([1.5, 3])
with col1:
    analyze_btn = st.button("🔍 Analyze My Discharge", type="primary", use_container_width=True)

# ── Analysis Pipeline (runs once on button click, saves to session state) ────
if analyze_btn:
    text = discharge_input.strip()
    if not text:
        st.error("Please paste a discharge summary before clicking Analyze.")
        st.stop()

    # Timing tracker for pipeline performance display
    timings = {}
    pipeline_start = time.time()

    # ── Step 1: Extract (Prompt Engineering) ─────────────────────────────
    with st.status("🔬 Step 1/5: Extracting clinical data...", expanded=False) as s:
        st.markdown(
            '<span class="component-badge badge-prompt" role="status" '
            'aria-label="Prompt Engineering component active">Prompt Engineering</span>',
            unsafe_allow_html=True
        )
        t0 = time.time()
        extracted = extract(text)
        warnings  = validate(extracted)
        med_count = len(extracted.get("medications", []))
        timings["Extraction"] = time.time() - t0
        s.update(label=f"✅ Step 1 — {med_count} medications extracted", state="complete")

    # ── Step 2: Drug Check (FDA API) ─────────────────────────────────────
    with st.status("💊 Step 2/5: Checking FDA drug interactions...", expanded=False) as s:
        t0 = time.time()
        interactions = check_interactions(extracted.get("medications", []))
        n = len(interactions)
        timings["Drug Check"] = time.time() - t0
        label = f"✅ Step 2 — {n} interaction(s) detected" if n else "✅ Step 2 — no interactions"
        s.update(label=label, state="complete")

    # ── Step 3: RAG Retrieval ────────────────────────────────────────────
    rag_context = ""
    retrieved_chunks = []
    with st.status("📚 Step 3/5: Retrieving patient education context...", expanded=False) as s:
        st.markdown(
            '<span class="component-badge badge-rag" role="status" '
            'aria-label="RAG component active">RAG</span>',
            unsafe_allow_html=True
        )
        t0 = time.time()
        try:
            from rag_knowledge import retrieve, format_rag_context
            diagnosis = extracted.get("primary_diagnosis", "")
            med_names = [m["name"] for m in extracted.get("medications", [])]
            retrieved_chunks = retrieve(
                "patient education guidelines",
                diagnosis=diagnosis,
                medications=med_names
            )
            rag_context = format_rag_context(retrieved_chunks)
            s.update(label=f"✅ Step 3 — {len(retrieved_chunks)} education chunks retrieved", state="complete")
        except Exception as e:
            s.update(label=f"⚠️ Step 3 — RAG unavailable ({e})", state="complete")
        timings["RAG Retrieval"] = time.time() - t0

    # ── Step 4: Generate Action Plan ─────────────────────────────────────
    with st.status("✍️ Step 4/5: Writing your action plan...", expanded=False) as s:
        st.markdown(
            '<span class="component-badge badge-prompt" role="status" '
            'aria-label="Prompt Engineering component active">Prompt Engineering</span>'
            '<span class="component-badge badge-finetune" role="status" '
            'aria-label="Fine-Tuning component active">Fine-Tuning</span>',
            unsafe_allow_html=True
        )
        t0 = time.time()
        result = generate(extracted, interactions, rag_context=rag_context)
        grade  = result["grade_level"]
        timings["Generation"] = time.time() - t0
        s.update(label=f"✅ Step 4 — Grade {grade} reading level", state="complete")

    # ── Step 5: Generate Visual Schedule (Multimodal) ────────────────────
    schedule_png_bytes = None
    schedule_pdf_bytes = None
    alarm_suggestions = []
    with st.status("🖼️ Step 5/5: Creating visual medication schedule...", expanded=False) as s:
        st.markdown(
            '<span class="component-badge badge-multi" role="status" '
            'aria-label="Multimodal component active">Multimodal</span>',
            unsafe_allow_html=True
        )
        t0 = time.time()
        try:
            from multimodal import generate_medication_schedule, get_alarm_suggestions
            schedule_path, schedule_pdf = generate_medication_schedule(
                extracted.get("medications", []),
                diagnosis=extracted.get("primary_diagnosis", ""),
                save_path=os.path.join(tempfile.gettempdir(), "med_schedule.png")
            )
            alarm_suggestions = get_alarm_suggestions(extracted.get("medications", []))
            # Read file bytes into memory so they survive reruns
            if schedule_path and os.path.exists(schedule_path):
                with open(schedule_path, "rb") as f:
                    schedule_png_bytes = f.read()
            if schedule_pdf and os.path.exists(schedule_pdf):
                with open(schedule_pdf, "rb") as f:
                    schedule_pdf_bytes = f.read()
            s.update(label="✅ Step 5 — Visual schedule generated", state="complete")
        except Exception as e:
            s.update(label=f"⚠️ Step 5 — Schedule unavailable ({e})", state="complete")
        timings["Visual Schedule"] = time.time() - t0

    total_time = time.time() - pipeline_start

    # ── Save everything to session state ─────────────────────────────────
    st.session_state.results = {
        "extracted":          extracted,
        "warnings":           warnings,
        "med_count":          med_count,
        "interactions":       interactions,
        "n_interactions":     n,
        "result":             result,
        "grade":              grade,
        "retrieved_chunks":   retrieved_chunks,
        "rag_context":        rag_context,
        "schedule_png_bytes": schedule_png_bytes,
        "schedule_pdf_bytes": schedule_pdf_bytes,
        "alarm_suggestions":  alarm_suggestions,
        "timings":            timings,
        "total_time":         total_time,
    }


# ── Display Results (persists across reruns via session state) ────────────────
if st.session_state.results:
    R = st.session_state.results
    extracted          = R["extracted"]
    warnings           = R["warnings"]
    med_count          = R["med_count"]
    interactions       = R["interactions"]
    n                  = R["n_interactions"]
    result             = R["result"]
    grade              = R["grade"]
    retrieved_chunks   = R["retrieved_chunks"]
    rag_context        = R["rag_context"]
    schedule_png_bytes = R["schedule_png_bytes"]
    schedule_pdf_bytes = R["schedule_pdf_bytes"]
    alarm_suggestions  = R["alarm_suggestions"]
    timings            = R["timings"]
    total_time         = R["total_time"]

    res_col1, res_col2 = st.columns([3, 1])
    with res_col1:
        st.success(f"🎉 Your personalized action plan is ready! (completed in {total_time:.1f}s)")
    with res_col2:
        if st.button("🗑️ Clear Results", use_container_width=True):
            st.session_state.results = None
            st.rerun()
    st.divider()

    # ── Metrics ──────────────────────────────────────────────────────────
    m1, m2, m3, m4, m5 = st.columns(5)
    m1.metric("💊 Medications",    med_count)
    m2.metric("⚠️ Interactions",  n,
              delta="Review required" if n else None,
              delta_color="inverse")
    m3.metric("📖 Reading Grade",  f"Grade {grade}",
              delta="✓ Target met" if result["target_met"] else "Above target",
              delta_color="normal" if result["target_met"] else "inverse")
    m4.metric("🔁 Simplify Runs",  result["retries_needed"])
    m5.metric("📚 RAG Context",    "Yes" if result["rag_context_used"] else "No")
    st.divider()

    # ── Readability Check Details ────────────────────────────────────────
    rc = result.get("readability_check")
    if rc:
        method = "ML Classifier + Flesch-Kincaid" if rc["model_used"] else "Flesch-Kincaid"
        if rc["label"] == "PASS":
            st.markdown(
                f'<div class="success-box">✅ <b>Readability: PASS</b> — '
                f'Grade {rc["fk_grade"]} (method: {method}, confidence: {rc["confidence"]:.0%})</div>',
                unsafe_allow_html=True
            )
        else:
            st.markdown(
                f'<div class="warning-box">⚠️ <b>Readability: NEEDS REVIEW</b> — '
                f'Grade {rc["fk_grade"]} (method: {method})</div>',
                unsafe_allow_html=True
            )

    # ── Extraction warnings ──────────────────────────────────────────────
    for w in warnings:
        st.warning(w)

    # ── Drug interaction alerts ──────────────────────────────────────────
    if interactions:
        st.markdown("### 🚨 Drug Interaction Alerts")
        st.caption("Verified against the U.S. FDA drug label database.")
        for w in interactions:
            if w["severity"] == "HIGH":
                st.markdown(
                    f'<div class="danger-box">🔴 <b>HIGH RISK:</b> '
                    f'<b>{w["drug_a"]}</b> + <b>{w["drug_b"]}</b><br>'
                    f'{w["message"]}<br>'
                    f'<small>Source: {w["source"]} | '
                    f'<a href="{w["fda_url"]}" target="_blank">FDA Reference ↗</a></small></div>',
                    unsafe_allow_html=True
                )
            else:
                st.markdown(
                    f'<div class="warning-box">🟡 <b>MODERATE:</b> '
                    f'<b>{w["drug_a"]}</b> + <b>{w["drug_b"]}</b><br>'
                    f'{w["message"]}<br>'
                    f'<small>Source: {w["source"]} | '
                    f'<a href="{w["fda_url"]}" target="_blank">FDA Reference ↗</a></small></div>',
                    unsafe_allow_html=True
                )
        st.caption("⚕️ Always discuss these alerts with your doctor or pharmacist.")
        st.divider()

    # ── Visual Medication Schedule (Multimodal) ──────────────────────────
    if schedule_png_bytes:
        st.markdown("### 🖼️ Your Visual Medication Schedule")
        st.caption("Color-coded daily schedule — blue = standard, orange = take with food")
        st.image(schedule_png_bytes, use_container_width=True)

        # Download buttons: PNG + printable PDF
        dl_col1, dl_col2 = st.columns(2)
        with dl_col1:
            st.download_button(
                label="⬇️ Download as Image (PNG)",
                data=schedule_png_bytes,
                file_name="medication_schedule.png",
                mime="image/png"
            )
        with dl_col2:
            if schedule_pdf_bytes:
                st.download_button(
                    label="🖨️ Download Printable (PDF)",
                    data=schedule_pdf_bytes,
                    file_name="medication_schedule.pdf",
                    mime="application/pdf"
                )

        # ── Alarm Suggestions ────────────────────────────────────────────
        if alarm_suggestions:
            st.markdown("#### ⏰ Suggested Phone Alarms")
            st.caption("Set these reminders on your phone so you never miss a dose.")
            for alarm in alarm_suggestions:
                meds_list = ", ".join(alarm["medications"])
                st.markdown(
                    f'<div class="success-box" role="listitem" '
                    f'aria-label="Alarm at {alarm["time"]}">'
                    f'⏰ <b>{alarm["time"]}</b> ({alarm["slot"]})<br>'
                    f'{meds_list}</div>',
                    unsafe_allow_html=True
                )
        st.divider()

    # ── Patient Action Plan ──────────────────────────────────────────────
    st.markdown("### 📋 Your Personal Action Plan")
    st.caption(f"Written at a Grade {grade} reading level — designed to be easy to understand.")
    st.markdown(result["text"])
    st.divider()

    # ── Raw data expander ────────────────────────────────────────────────
    with st.expander("🔧 View Raw Extracted Data (Technical Details)"):
        st.caption("Structured data extracted from your document.")
        st.json(extracted)

    # ── RAG sources — Confidence-Weighted Display ────────────────────────
    if retrieved_chunks:
        with st.expander("📚 View RAG Knowledge Sources (Relevance-Ranked)"):
            st.caption(
                "Patient education materials retrieved from the knowledge base, "
                "ranked by semantic relevance to your diagnosis and medications."
            )
            for r in retrieved_chunks:
                distance = r.get("distance", 1.0)
                relevance = max(0.0, min(1.0, 1.0 - distance))
                topic = r.get("topic", "Unknown")
                source = r.get("source", "unknown")

                st.markdown(f"**{topic}** — `{source}`")
                st.progress(relevance, text=f"Relevance: {relevance:.0%}")
                st.text(r["text"][:300] + ("..." if len(r["text"]) > 300 else ""))
                st.markdown("---")
    elif rag_context:
        with st.expander("📚 View RAG Knowledge Sources"):
            st.caption("Patient education materials retrieved from the knowledge base.")
            st.text(rag_context[:3000])

    # ── Pipeline Performance ─────────────────────────────────────────────
    with st.expander("⚡ Pipeline Performance"):
        timing_parts = " | ".join(
            f"{step}: {dur:.1f}s" for step, dur in timings.items()
        )
        st.markdown(
            f'<div class="timing-box" role="status" '
            f'aria-label="Pipeline performance summary">'
            f'🕐 <b>Total: {total_time:.1f}s</b><br>'
            f'{timing_parts}</div>',
            unsafe_allow_html=True
        )
        if timings:
            st.caption("Time spent per stage:")
            for step, dur in timings.items():
                fraction = dur / total_time if total_time > 0 else 0
                st.progress(fraction, text=f"{step}: {dur:.1f}s ({fraction:.0%})")

    # ── Component architecture expander ──────────────────────────────────
    with st.expander("🏗️ System Architecture — 5 Core Components"):
        st.markdown("""
**1. Prompt Engineering** — Structured extraction prompts with JSON schema
enforcement, patient education generation with readability constraints,
and automatic retry/simplify loop for plain-language output.

**2. RAG (Retrieval-Augmented Generation)** — Patient education knowledge
base built from trusted medical education materials. ChromaDB vector store
with sentence-transformer embeddings retrieves condition-specific guidance
at generation time. Results ranked by semantic relevance.

**3. Multimodal Integration** — OCR for scanned PDF discharge documents
(pytesseract) with confidence scoring and noise filtering, plus a visual
medication schedule generator (matplotlib) with printable PDF export
and alarm time suggestions.

**4. Synthetic Data Generation** — Diverse discharge summaries generated
across 8 diagnosis categories, 3 complexity tiers, and 5 formatting styles
with auto-annotated ground truth for evaluation. Also used to augment
fine-tuning training data (Component 4 → Component 5 loop).

**5. Fine-Tuning** — DistilBERT readability classifier fine-tuned on
medical text (40 curated + 60 augmented examples) to detect jargon
complexity that formula-based metrics miss. Evaluated with precision,
recall, and F1. Serves as a validation gate alongside Flesch-Kincaid scoring.
        """)

    # ── Downloads ────────────────────────────────────────────────────────
    st.download_button(
        label="⬇️ Download Action Plan as .txt",
        data=result["text"],
        file_name="my_action_plan.txt",
        mime="text/plain"
    )
