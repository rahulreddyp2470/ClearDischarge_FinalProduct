"""
ClearDischarge — Stage 2: FDA Drug Interaction Checker
══════════════════════════════════════════════════════
Checks medication pairs against the OpenFDA drug label
database and a hardcoded high-risk interaction table.
"""

import requests
import itertools

FDA_URL = "https://api.fda.gov/drug/label.json"

# Known high-risk interaction pairs (fallback safety net)
HIGH_RISK_PAIRS = [
    ("warfarin",    "aspirin"),
    ("warfarin",    "ibuprofen"),
    ("warfarin",    "naproxen"),
    ("lisinopril",  "potassium"),
    ("lisinopril",  "spironolactone"),
    ("furosemide",  "gentamicin"),
    ("metformin",   "contrast"),
    ("carvedilol",  "verapamil"),
    ("digoxin",     "amiodarone"),
    ("clopidogrel", "omeprazole"),
]


def _normalize(name: str) -> str:
    """Lowercase and strip brand names in parentheses for matching."""
    return name.lower().split("(")[0].strip()


def _query_fda(drug_name: str) -> dict | None:
    """Query OpenFDA for a drug's label — returns label data or None."""
    try:
        params = {
            "search": f'openfda.generic_name:"{drug_name}"',
            "limit": 1
        }
        r = requests.get(FDA_URL, params=params, timeout=8)
        if r.status_code == 200:
            results = r.json().get("results", [])
            return results[0] if results else None
        # Try brand name if generic fails
        params["search"] = f'openfda.brand_name:"{drug_name}"'
        r = requests.get(FDA_URL, params=params, timeout=8)
        if r.status_code == 200:
            results = r.json().get("results", [])
            return results[0] if results else None
    except requests.RequestException:
        return None
    return None


def _check_label_interactions(label: dict, other_drugs: list[str]) -> list[str]:
    """Search a drug's FDA label text for mentions of other drugs."""
    hits = []
    interaction_text = " ".join([
        " ".join(label.get("drug_interactions", [])),
        " ".join(label.get("warnings", [])),
        " ".join(label.get("precautions", []))
    ]).lower()

    for other in other_drugs:
        name_clean = _normalize(other)
        if name_clean and name_clean in interaction_text:
            hits.append(other)
    return hits


def _check_hardcoded(drug_a: str, drug_b: str) -> bool:
    """Check if a pair matches any known high-risk pairs."""
    a, b = _normalize(drug_a), _normalize(drug_b)
    for p1, p2 in HIGH_RISK_PAIRS:
        if (p1 in a or a in p1) and (p2 in b or b in p2):
            return True
        if (p1 in b or b in p1) and (p2 in a or a in p2):
            return True
    return False


def check_interactions(medications: list[dict]) -> list[dict]:
    """
    Main function. Takes the medications list from extractor.py.
    Returns a list of interaction warning objects.
    """
    if len(medications) < 2:
        return []

    warnings = []
    names = [m["name"] for m in medications]

    for drug_a, drug_b in itertools.combinations(names, 2):
        interaction_found = False
        source = ""

        # Step 1: Check hardcoded high-risk pairs (fast)
        if _check_hardcoded(drug_a, drug_b):
            interaction_found = True
            source = "Known high-risk interaction (clinical reference)"

        # Step 2: Query FDA label
        if not interaction_found:
            label = _query_fda(_normalize(drug_a))
            if label:
                hits = _check_label_interactions(label, [drug_b])
                if hits:
                    interaction_found = True
                    source = f"FDA drug label for {drug_a}"

        if interaction_found:
            warnings.append({
                "drug_a":   drug_a,
                "drug_b":   drug_b,
                "severity": _get_severity(drug_a, drug_b),
                "message":  _get_message(drug_a, drug_b),
                "source":   source,
                "fda_url":  "https://www.fda.gov/drugs/drug-interactions-labeling/drug-interactions"
            })

    return warnings


def _get_severity(a: str, b: str) -> str:
    a_n, b_n = _normalize(a), _normalize(b)
    high_risk = [
        ("warfarin", "aspirin"), ("warfarin", "ibuprofen"),
        ("warfarin", "naproxen"), ("digoxin", "amiodarone")
    ]
    for p1, p2 in high_risk:
        if (p1 in a_n or p1 in b_n) and (p2 in a_n or p2 in b_n):
            return "HIGH"
    return "MODERATE"


def _get_message(a: str, b: str) -> str:
    a_n, b_n = _normalize(a), _normalize(b)
    messages = {
        ("warfarin", "aspirin"):       "Taking Warfarin with Aspirin significantly increases bleeding risk.",
        ("warfarin", "ibuprofen"):     "Ibuprofen can increase Warfarin's blood-thinning effect and raise bleeding risk.",
        ("warfarin", "naproxen"):      "Naproxen can increase Warfarin's effect and raise bleeding risk.",
        ("lisinopril", "potassium"):   "Lisinopril can raise potassium levels — taking extra potassium may cause dangerously high levels.",
        ("furosemide", "gentamicin"):  "Both drugs can damage kidneys — combining them increases that risk.",
        ("digoxin", "amiodarone"):     "Amiodarone raises Digoxin levels in the blood, which can become toxic.",
        ("carvedilol", "verapamil"):   "Both drugs slow heart rate — combining them may cause the heart to beat too slowly.",
        ("clopidogrel", "omeprazole"): "Omeprazole can reduce how well Clopidogrel works to prevent blood clots.",
    }
    for (p1, p2), msg in messages.items():
        if (p1 in a_n or p1 in b_n) and (p2 in a_n or p2 in b_n):
            return msg
    return f"A documented interaction exists between {a} and {b}. Consult your pharmacist."


def verify_drug_exists(drug_name: str) -> bool:
    """Check if a drug name exists in the FDA database — catches hallucinations."""
    return _query_fda(_normalize(drug_name)) is not None


# ── Test block ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import json, pathlib

    p = pathlib.Path("last_extraction.json")
    if p.exists():
        data = json.loads(p.read_text())
        meds = data.get("medications", [])
    else:
        meds = [
            {"name": "Warfarin",           "dose": "5mg",   "frequency": "once daily"},
            {"name": "Aspirin",            "dose": "81mg",  "frequency": "once daily"},
            {"name": "Lisinopril",         "dose": "10mg",  "frequency": "once daily"},
            {"name": "Potassium Chloride", "dose": "20mEq", "frequency": "twice daily"},
        ]

    print(f"\nChecking {len(meds)} medications for interactions...\n")
    interactions = check_interactions(meds)

    if not interactions:
        print("✅ No drug interactions detected.")
    else:
        print(f"⚠️  {len(interactions)} interaction(s) found:\n")
        for w in interactions:
            sev_icon = "🔴" if w["severity"] == "HIGH" else "🟡"
            print(f"{sev_icon} [{w['severity']}] {w['drug_a']} + {w['drug_b']}")
            print(f"   {w['message']}")
            print(f"   Source: {w['source']}")
            print(f"   Reference: {w['fda_url']}\n")
