"""
ClearDischarge — Component 2: RAG (Retrieval-Augmented Generation)
═══════════════════════════════════════════════════════════════════
Builds a patient education knowledge base from trusted medical
education documents. Retrieves relevant context at generation time
to enrich the action plan with condition-specific guidance.

Uses: ChromaDB (vector store) + sentence-transformers (embeddings)
"""

import os
import glob
import chromadb
from chromadb.utils import embedding_functions

# ── Configuration ────────────────────────────────────────────────────────────
KB_DIR          = os.path.join(os.path.dirname(__file__), "knowledge_base")
CHROMA_DIR      = os.path.join(os.path.dirname(__file__), ".chroma_db")
COLLECTION_NAME = "patient_education"
CHUNK_SIZE      = 500   # characters per chunk
CHUNK_OVERLAP   = 100   # overlap between chunks
TOP_K           = 5     # number of chunks to retrieve


def _chunk_text(text: str, chunk_size: int = CHUNK_SIZE,
                overlap: int = CHUNK_OVERLAP) -> list[str]:
    """
    Split text into overlapping chunks by paragraph boundaries.
    Strategy: split on double-newlines first (paragraph-level),
    then merge small paragraphs and split large ones.
    """
    paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
    chunks = []
    current = ""

    for para in paragraphs:
        if len(current) + len(para) < chunk_size:
            current = current + "\n\n" + para if current else para
        else:
            if current:
                chunks.append(current.strip())
            # If a single paragraph exceeds chunk_size, split by sentences
            if len(para) > chunk_size:
                sentences = para.replace(". ", ".\n").split("\n")
                sub = ""
                for s in sentences:
                    if len(sub) + len(s) < chunk_size:
                        sub = sub + " " + s if sub else s
                    else:
                        if sub:
                            chunks.append(sub.strip())
                        sub = s
                if sub:
                    current = sub
            else:
                current = para

    if current.strip():
        chunks.append(current.strip())

    return chunks


def build_knowledge_base(force_rebuild: bool = False) -> chromadb.Collection:
    """
    Build (or load) the ChromaDB knowledge base from .txt files
    in the knowledge_base/ directory.

    Document chunking strategy:
    - Paragraph-level splitting with 100-char overlap
    - Preserves semantic coherence within chunks
    - Metadata tracks source file and chunk index
    """
    # Use sentence-transformers for medical-domain embeddings
    ef = embedding_functions.SentenceTransformerEmbeddingFunction(
        model_name="all-MiniLM-L6-v2"
    )

    client = chromadb.PersistentClient(path=CHROMA_DIR)

    # Check if collection exists and has data
    try:
        collection = client.get_collection(
            name=COLLECTION_NAME,
            embedding_function=ef
        )
        if collection.count() > 0 and not force_rebuild:
            print(f"📚 Knowledge base loaded: {collection.count()} chunks")
            return collection
        # If force rebuild, delete and recreate
        client.delete_collection(COLLECTION_NAME)
    except Exception:
        pass

    # Create fresh collection
    collection = client.create_collection(
        name=COLLECTION_NAME,
        embedding_function=ef,
        metadata={"description": "Patient education materials for discharge guidance"}
    )

    # Load and chunk all .txt files from knowledge_base/
    txt_files = glob.glob(os.path.join(KB_DIR, "*.txt"))
    if not txt_files:
        print(f"⚠️  No .txt files found in {KB_DIR}")
        return collection

    all_docs     = []
    all_ids      = []
    all_metadata = []

    for filepath in txt_files:
        filename = os.path.basename(filepath)
        topic    = filename.replace(".txt", "").replace("_", " ").title()

        with open(filepath, "r", encoding="utf-8") as f:
            text = f.read()

        chunks = _chunk_text(text)
        for i, chunk in enumerate(chunks):
            doc_id = f"{filename}__chunk_{i:03d}"
            all_docs.append(chunk)
            all_ids.append(doc_id)
            all_metadata.append({
                "source":      filename,
                "topic":       topic,
                "chunk_index": i,
                "total_chunks": len(chunks)
            })

    # Add to ChromaDB in batches
    batch_size = 50
    for start in range(0, len(all_docs), batch_size):
        end = min(start + batch_size, len(all_docs))
        collection.add(
            documents=all_docs[start:end],
            ids=all_ids[start:end],
            metadatas=all_metadata[start:end]
        )

    print(f"✅ Knowledge base built: {len(all_docs)} chunks from {len(txt_files)} documents")
    return collection


def retrieve(query: str, diagnosis: str = "",
             medications: list[str] = None, top_k: int = TOP_K) -> list[dict]:
    """
    Retrieve relevant patient education chunks for a given query.

    Ranking strategy:
    - Combines diagnosis + medication names into a rich query
    - Returns top_k most semantically similar chunks
    - Includes source metadata for transparency
    """
    # Build a composite query for better retrieval
    parts = []
    if diagnosis:
        parts.append(f"Patient diagnosed with {diagnosis}.")
    if medications:
        parts.append(f"Taking medications: {', '.join(medications[:6])}.")
    if query:
        parts.append(query)
    composite_query = " ".join(parts) if parts else query

    # Load or build the collection
    collection = build_knowledge_base()

    if collection.count() == 0:
        return []

    results = collection.query(
        query_texts=[composite_query],
        n_results=min(top_k, collection.count())
    )

    # Format results
    retrieved = []
    for i in range(len(results["documents"][0])):
        retrieved.append({
            "text":     results["documents"][0][i],
            "source":   results["metadatas"][0][i].get("source", "unknown"),
            "topic":    results["metadatas"][0][i].get("topic", "unknown"),
            "distance": results["distances"][0][i] if results.get("distances") else None
        })

    return retrieved


def format_rag_context(retrieved: list[dict]) -> str:
    """
    Format retrieved chunks into a context block for the generator prompt.
    Includes source attribution for each chunk.
    """
    if not retrieved:
        return ""

    sections = []
    for r in retrieved:
        sections.append(
            f"[Source: {r['topic']}]\n{r['text']}"
        )

    return (
        "PATIENT EDUCATION REFERENCE MATERIAL (from trusted medical sources):\n"
        + "\n\n---\n\n".join(sections)
        + "\n\nUse the above reference material to enrich your Patient Action Plan "
        "with condition-specific guidance. Only include information that is relevant "
        "to this patient's specific diagnosis and medications."
    )


# ── Test block ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print("Building knowledge base...\n")
    collection = build_knowledge_base(force_rebuild=True)

    print(f"\nTotal chunks in vector store: {collection.count()}")

    # Test retrieval
    test_queries = [
        ("heart failure fluid restriction", "CHF", ["Furosemide", "Lisinopril"]),
        ("diabetes blood sugar monitoring",  "Type 2 Diabetes", ["Metformin", "Glipizide"]),
        ("pneumonia recovery breathing",     "Pneumonia", ["Azithromycin", "Albuterol"]),
        ("hip replacement blood clot",       "Hip Replacement", ["Enoxaparin", "Oxycodone"]),
    ]

    for query, dx, meds in test_queries:
        print(f"\n{'─'*60}")
        print(f"Query: {query} | Dx: {dx}")
        results = retrieve(query, diagnosis=dx, medications=meds, top_k=3)
        for r in results:
            print(f"  📄 [{r['topic']}] (distance: {r['distance']:.3f})")
            print(f"     {r['text'][:120]}...")
