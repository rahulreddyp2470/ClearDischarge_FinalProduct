"""
ClearDischarge — Component 5: Fine-Tuning (Readability Classifier)
═════════════════════════════════════════════════════════════════
Fine-tunes a DistilBERT model to classify whether medical text
meets the Grade 8 readability target.

Why not just Flesch-Kincaid?
- FK is formula-based (syllable + sentence length) — it misunderstands
  medical jargon that is short but complex (e.g., "edema", "dyspnea")
- A fine-tuned model learns that domain-specific terms raise real
  complexity even when syllable counts say otherwise

Pipeline:
  1. Generate training data (medical text + readability labels)
  2. Fine-tune DistilBERT as a binary classifier (PASS / FAIL)
  3. Export model for use as a validation gate in the pipeline

Uses: transformers, torch, scikit-learn, datasets
"""

import os
import json
import random
import numpy as np
import textstat

# ── Training Data ────────────────────────────────────────────────────────────
# Curated examples of PASS (≤ Grade 8) and FAIL (> Grade 8) medical text.
# In production, this would be much larger and human-annotated.

TRAINING_DATA = [
    # ── PASS examples (plain language, ≤ Grade 8) ────────────────────────
    {"text": "Take your water pill every morning. It helps your body get rid of extra fluid. You may need to use the bathroom more often.", "label": 1},
    {"text": "Weigh yourself every morning before you eat. Write down your weight. Call your doctor if you gain more than 2 pounds in one day.", "label": 1},
    {"text": "Do not eat more than 2 grams of salt per day. Avoid canned soup, chips, and fast food. Use lemon or herbs instead of salt.", "label": 1},
    {"text": "Take this medicine with food to avoid an upset stomach. Swallow the pill whole with a full glass of water.", "label": 1},
    {"text": "Check your blood sugar twice a day. Write down the numbers. Bring your log to your next doctor visit.", "label": 1},
    {"text": "Do not drive if your blood sugar is below 70. Eat a snack first and wait until you feel better.", "label": 1},
    {"text": "Walk for 10 minutes each day. Start slow and rest when you need to. Stop if you feel dizzy or short of breath.", "label": 1},
    {"text": "Your wound should stay dry for 3 days. Do not soak in a bath or pool. You can take a shower after your doctor says it is okay.", "label": 1},
    {"text": "Go to the emergency room right away if you have chest pain that lasts more than 15 minutes.", "label": 1},
    {"text": "Take your blood pressure medicine at the same time every day. Do not skip doses even if you feel fine.", "label": 1},
    {"text": "Drink at least 8 glasses of water each day. This helps your lungs clear out mucus from the infection.", "label": 1},
    {"text": "Use your inhaler before you exercise. Wait 2 minutes between puffs. Rinse your mouth after using it.", "label": 1},
    {"text": "Do not lift anything heavier than 10 pounds for 6 weeks after your surgery.", "label": 1},
    {"text": "Eat small meals throughout the day instead of 3 large meals. This can help with nausea.", "label": 1},
    {"text": "Sit up straight when you eat. Stay sitting up for at least 30 minutes after eating.", "label": 1},
    {"text": "Take all of your antibiotics even if you feel better. Stopping early can make the infection come back.", "label": 1},
    {"text": "Put ice on your knee for 20 minutes at a time. Use a thin cloth between the ice and your skin.", "label": 1},
    {"text": "Call your doctor if the redness around your wound gets bigger or if you see pus.", "label": 1},
    {"text": "You may feel tired for several weeks after leaving the hospital. This is normal. Rest when your body tells you to.", "label": 1},
    {"text": "Keep a list of all your medicines in your wallet. Show it to every doctor you visit.", "label": 1},

    # ── FAIL examples (medical jargon, > Grade 8) ───────────────────────
    {"text": "The patient is to continue carvedilol for rate control of atrial fibrillation with rapid ventricular response and systolic dysfunction.", "label": 0},
    {"text": "Administer enoxaparin 40mg subcutaneously once daily for DVT prophylaxis following total hip arthroplasty.", "label": 0},
    {"text": "The etiology of the acute kidney injury is likely prerenal secondary to intravascular volume depletion in the setting of aggressive diuresis.", "label": 0},
    {"text": "Recommend initiating anticoagulation therapy with warfarin targeting an INR of 2.0-3.0 for thromboembolic prophylaxis.", "label": 0},
    {"text": "The patient demonstrated progressive dyspnea on exertion with bilateral lower extremity edema consistent with decompensated heart failure.", "label": 0},
    {"text": "Hemoglobin A1c of 11.2% indicates severely uncontrolled glycemic status requiring intensification of the antihyperglycemic regimen.", "label": 0},
    {"text": "Differential diagnosis includes pulmonary embolism, acute coronary syndrome, and tension pneumothorax given the acute presentation.", "label": 0},
    {"text": "Hepatorenal syndrome was considered given the concurrent hepatic cirrhosis and progressive azotemia unresponsive to volume resuscitation.", "label": 0},
    {"text": "Echocardiographic findings revealed an ejection fraction of 25% with global hypokinesis and moderate mitral regurgitation.", "label": 0},
    {"text": "The patient was treated empirically with piperacillin-tazobactam and vancomycin pending blood culture susceptibility results.", "label": 0},
    {"text": "Nephrology was consulted regarding the hyperkalemia refractory to medical management including insulin-glucose infusion and sodium polystyrene.", "label": 0},
    {"text": "Postoperative radiograph confirmed appropriate alignment of the prosthetic components without evidence of periprosthetic fracture.", "label": 0},
    {"text": "Cerebrovascular accident in the left middle cerebral artery distribution resulting in right hemiparesis and expressive aphasia.", "label": 0},
    {"text": "The patient's creatinine clearance calculated at 32 mL/min necessitates renal dose adjustment of all renally-cleared medications.", "label": 0},
    {"text": "Discontinue metformin in the perioperative period given the risk of lactic acidosis in the setting of potential hemodynamic compromise.", "label": 0},
    {"text": "Serum troponin trending upward from 0.04 to 0.28 ng/mL consistent with type 2 myocardial infarction in the setting of demand ischemia.", "label": 0},
    {"text": "Electroencephalography demonstrated epileptiform discharges originating from the left temporal lobe with secondary generalization.", "label": 0},
    {"text": "Titrate the angiotensin receptor blocker to maximize neurohormonal blockade while monitoring for symptomatic hypotension and hyperkalemia.", "label": 0},
    {"text": "The bronchoalveolar lavage cytology was consistent with eosinophilic pneumonia and the patient was started on systemic corticosteroids.", "label": 0},
    {"text": "Consider bridging anticoagulation with low-molecular-weight heparin perioperatively given the mechanical mitral valve prosthesis.", "label": 0},
]


# ── Data Augmentation ────────────────────────────────────────────────────────
# Augmentation templates create paraphrased variants of PASS/FAIL examples
# to increase training data diversity without API calls.

PASS_TEMPLATES = [
    "Take your {med} every {time}. It helps with {condition}.",
    "You need to {action} every day. Write it down in a log.",
    "Do not eat {food}. Try {alternative} instead.",
    "Call your doctor right away if you notice {symptom}.",
    "Walk for {duration} minutes each day. Rest when you feel tired.",
    "Your next doctor visit is in {timeframe}. Do not miss it.",
    "Drink {amount} glasses of water each day to stay healthy.",
    "Take this pill with a full glass of water. Do not crush or chew it.",
    "Keep all your medicines in one place. Bring the list to every visit.",
    "It is normal to feel tired after leaving the hospital. Rest often.",
]

FAIL_TEMPLATES = [
    "The patient requires {med} titration for {condition} management with ongoing hemodynamic monitoring.",
    "Recommend discontinuation of {med} given contraindication with concurrent {condition} and renal insufficiency.",
    "Echocardiographic assessment revealed {finding} necessitating cardiology consultation for further evaluation.",
    "The differential includes {condition} secondary to {etiology} in the setting of immunosuppression.",
    "Initiate prophylactic anticoagulation with {med} targeting therapeutic {lab} levels perioperatively.",
    "Serum {lab} levels trending upward consistent with {condition} requiring nephrology input.",
    "Cerebrovascular imaging demonstrated {finding} with resultant neurological deficit requiring rehabilitation.",
    "The patient exhibited progressive {symptom} refractory to standard pharmacological intervention.",
    "Consider empiric broad-spectrum antimicrobial coverage pending {lab} susceptibility results.",
    "Postoperative course complicated by {condition} managed conservatively with serial {lab} monitoring.",
]

AUGMENT_FILLS = {
    "med": ["Lisinopril", "Metformin", "Furosemide", "Amlodipine", "Atorvastatin"],
    "time": ["morning", "evening", "day", "night"],
    "condition": ["heart failure", "high blood pressure", "diabetes", "pneumonia", "kidney problems"],
    "action": ["check your blood sugar", "weigh yourself", "take your blood pressure", "check your wound"],
    "food": ["salty foods", "fried food", "fast food", "canned soup"],
    "alternative": ["herbs and spices", "fresh fruit", "grilled chicken", "steamed vegetables"],
    "symptom": ["chest pain", "trouble breathing", "swelling in your legs", "sudden weight gain"],
    "duration": ["10", "15", "20", "30"],
    "timeframe": ["1 week", "2 weeks", "3 days", "10 days"],
    "amount": ["6", "8", "10"],
    "finding": ["reduced ejection fraction with global hypokinesis", "bilateral pleural effusions",
                "aortic valve stenosis with calcification"],
    "etiology": ["intravascular volume depletion", "septic embolization", "autoimmune vasculitis"],
    "lab": ["troponin", "creatinine", "INR", "potassium", "hemoglobin A1c"],
}


def augment_training_data(n_augmented: int = 60) -> list[dict]:
    """
    Generate augmented training examples by filling templates with
    medical terms. Creates a virtuous loop: diverse synthetic examples
    strengthen the readability classifier without API calls.

    This bridges Component 4 (Synthetic Data) and Component 5 (Fine-Tuning).

    Args:
        n_augmented: number of augmented examples to generate (split 50/50)

    Returns:
        Combined list of original + augmented training data.
    """
    import random
    random.seed(42)

    augmented = []
    half = n_augmented // 2

    # Generate PASS examples
    for i in range(half):
        template = random.choice(PASS_TEMPLATES)
        filled = template
        for key, options in AUGMENT_FILLS.items():
            placeholder = "{" + key + "}"
            if placeholder in filled:
                filled = filled.replace(placeholder, random.choice(options), 1)
        augmented.append({"text": filled, "label": 1})

    # Generate FAIL examples
    for i in range(half):
        template = random.choice(FAIL_TEMPLATES)
        filled = template
        for key, options in AUGMENT_FILLS.items():
            placeholder = "{" + key + "}"
            if placeholder in filled:
                filled = filled.replace(placeholder, random.choice(options), 1)
        augmented.append({"text": filled, "label": 0})

    combined = TRAINING_DATA + augmented
    print(f"📊 Training data: {len(TRAINING_DATA)} original + {len(augmented)} augmented = {len(combined)} total")
    return combined


def prepare_dataset(use_augmentation: bool = True):
    """
    Prepare training and validation splits.
    Optionally augments training data for better classifier performance.
    """
    from sklearn.model_selection import train_test_split

    data = augment_training_data() if use_augmentation else TRAINING_DATA

    texts  = [d["text"] for d in data]
    labels = [d["label"] for d in data]

    train_texts, val_texts, train_labels, val_labels = train_test_split(
        texts, labels, test_size=0.2, random_state=42, stratify=labels
    )

    return {
        "train": {"texts": train_texts, "labels": train_labels},
        "val":   {"texts": val_texts,   "labels": val_labels}
    }


def fine_tune(output_dir: str = "readability_model", epochs: int = 10,
              batch_size: int = 8, learning_rate: float = 2e-5):
    """
    Fine-tune DistilBERT as a binary readability classifier.

    Labels:
      1 = PASS (≤ Grade 8, appropriate for patients)
      0 = FAIL (> Grade 8, too complex)
    """
    import torch
    from torch.utils.data import DataLoader, Dataset
    from transformers import (
        DistilBertTokenizer, DistilBertForSequenceClassification,
        get_linear_schedule_with_warmup
    )

    print("Loading DistilBERT tokenizer and model...")
    tokenizer = DistilBertTokenizer.from_pretrained("distilbert-base-uncased")
    model     = DistilBertForSequenceClassification.from_pretrained(
        "distilbert-base-uncased", num_labels=2
    )

    # Label names for clarity
    model.config.id2label = {0: "FAIL", 1: "PASS"}
    model.config.label2id = {"FAIL": 0, "PASS": 1}

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)

    data = prepare_dataset()

    class ReadabilityDataset(Dataset):
        def __init__(self, texts, labels):
            self.encodings = tokenizer(texts, truncation=True,
                                        padding=True, max_length=256,
                                        return_tensors="pt")
            self.labels = torch.tensor(labels, dtype=torch.long)

        def __len__(self):
            return len(self.labels)

        def __getitem__(self, idx):
            return {
                "input_ids":      self.encodings["input_ids"][idx],
                "attention_mask": self.encodings["attention_mask"][idx],
                "labels":         self.labels[idx]
            }

    train_ds = ReadabilityDataset(data["train"]["texts"], data["train"]["labels"])
    val_ds   = ReadabilityDataset(data["val"]["texts"],   data["val"]["labels"])

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True)
    val_loader   = DataLoader(val_ds,   batch_size=batch_size)

    optimizer = torch.optim.AdamW(model.parameters(), lr=learning_rate)
    total_steps = len(train_loader) * epochs
    scheduler = get_linear_schedule_with_warmup(
        optimizer, num_warmup_steps=total_steps // 10,
        num_training_steps=total_steps
    )

    print(f"\nFine-tuning on {len(train_ds)} samples, validating on {len(val_ds)}")
    print(f"Device: {device} | Epochs: {epochs} | LR: {learning_rate}\n")

    best_val_acc = 0.0

    for epoch in range(epochs):
        # ── Training ──
        model.train()
        train_loss = 0.0
        for batch in train_loader:
            batch = {k: v.to(device) for k, v in batch.items()}
            outputs = model(**batch)
            loss = outputs.loss
            loss.backward()
            optimizer.step()
            scheduler.step()
            optimizer.zero_grad()
            train_loss += loss.item()

        # ── Validation ──
        model.eval()
        correct = 0
        total   = 0
        with torch.no_grad():
            for batch in val_loader:
                batch = {k: v.to(device) for k, v in batch.items()}
                outputs = model(**batch)
                preds = torch.argmax(outputs.logits, dim=-1)
                correct += (preds == batch["labels"]).sum().item()
                total   += len(batch["labels"])

        val_acc = correct / total if total else 0
        avg_loss = train_loss / len(train_loader)
        print(f"  Epoch {epoch+1}/{epochs}  |  Loss: {avg_loss:.4f}  |  Val Acc: {val_acc:.1%}")

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            model.save_pretrained(output_dir)
            tokenizer.save_pretrained(output_dir)

    print(f"\n✅ Best model saved to {output_dir}/ (val accuracy: {best_val_acc:.1%})")
    return output_dir


def load_classifier(model_dir: str = "readability_model"):
    """Load the fine-tuned readability classifier."""
    import torch
    from transformers import DistilBertTokenizer, DistilBertForSequenceClassification

    if not os.path.exists(model_dir):
        return None, None

    tokenizer = DistilBertTokenizer.from_pretrained(model_dir)
    model     = DistilBertForSequenceClassification.from_pretrained(model_dir)
    model.eval()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)

    return model, tokenizer


def predict_readability(text: str, model=None, tokenizer=None) -> dict:
    """
    Predict whether text passes the readability threshold.
    Falls back to Flesch-Kincaid if model not available.

    Returns:
        {"label": "PASS"/"FAIL", "confidence": float,
         "fk_grade": float, "model_used": bool}
    """
    fk_grade = textstat.flesch_kincaid_grade(text)

    if model is None or tokenizer is None:
        return {
            "label":      "PASS" if fk_grade <= 8.0 else "FAIL",
            "confidence": 1.0,
            "fk_grade":   round(fk_grade, 1),
            "model_used": False
        }

    import torch

    device = next(model.parameters()).device
    inputs = tokenizer(text, truncation=True, padding=True,
                       max_length=256, return_tensors="pt")
    inputs = {k: v.to(device) for k, v in inputs.items()}

    with torch.no_grad():
        outputs = model(**inputs)
        probs = torch.softmax(outputs.logits, dim=-1)
        pred  = torch.argmax(probs, dim=-1).item()
        conf  = probs[0][pred].item()

    label = "PASS" if pred == 1 else "FAIL"

    return {
        "label":      label,
        "confidence": round(conf, 3),
        "fk_grade":   round(fk_grade, 1),
        "model_used": True
    }


# ── Test block ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--train", action="store_true",
                        help="Fine-tune the readability model")
    parser.add_argument("--test", action="store_true",
                        help="Test the model on sample texts")
    parser.add_argument("--epochs", type=int, default=10)
    args = parser.parse_args()

    if args.train:
        fine_tune(epochs=args.epochs)

    if args.test:
        model, tokenizer = load_classifier()
        if model is None:
            print("No fine-tuned model found. Run with --train first.")
            print("Falling back to Flesch-Kincaid only.\n")

        # ── Quick demo on 4 examples ─────────────────────────────────────
        test_texts = [
            "Take your pill every morning with water. Call your doctor if you feel dizzy.",
            "The patient exhibited progressive dyspnea with bilateral pleural effusions requiring thoracentesis.",
            "Walk for 10 minutes each day. Stop if you feel tired or short of breath.",
            "Initiate anticoagulation with enoxaparin bridging to warfarin targeting therapeutic INR 2.0-3.0.",
        ]

        print("── Sample Predictions ──\n")
        for text in test_texts:
            result = predict_readability(text, model, tokenizer)
            icon = "✅" if result["label"] == "PASS" else "❌"
            model_tag = " [ML]" if result["model_used"] else " [FK]"
            print(f"{icon} {result['label']}{model_tag} (conf: {result['confidence']:.0%}, FK: {result['fk_grade']})")
            print(f"   \"{text[:80]}...\"\n")

        # ── Full evaluation on held-out validation set ────────────────────
        print("\n── Held-Out Validation Metrics ──\n")
        from sklearn.metrics import (
            precision_score, recall_score, f1_score,
            confusion_matrix, classification_report
        )

        data = prepare_dataset(use_augmentation=True)
        val_texts  = data["val"]["texts"]
        val_labels = data["val"]["labels"]

        preds = []
        for text in val_texts:
            result = predict_readability(text, model, tokenizer)
            pred_label = 1 if result["label"] == "PASS" else 0
            preds.append(pred_label)

        precision = precision_score(val_labels, preds, zero_division=0)
        recall    = recall_score(val_labels, preds, zero_division=0)
        f1        = f1_score(val_labels, preds, zero_division=0)
        cm        = confusion_matrix(val_labels, preds)

        print(f"  Precision : {precision:.3f}")
        print(f"  Recall    : {recall:.3f}")
        print(f"  F1 Score  : {f1:.3f}")
        print(f"\n  Confusion Matrix (rows=actual, cols=predicted):")
        print(f"               FAIL  PASS")
        print(f"    FAIL       {cm[0][0]:>4}  {cm[0][1]:>4}")
        print(f"    PASS       {cm[1][0]:>4}  {cm[1][1]:>4}")
        print(f"\n  Full Classification Report:")
        print(classification_report(
            val_labels, preds,
            target_names=["FAIL (jargon)", "PASS (plain)"],
            zero_division=0
        ))
