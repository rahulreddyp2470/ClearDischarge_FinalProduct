"""
ClearDischarge — Component 3: Multimodal Integration
════════════════════════════════════════════════════
Two sub-components:
  A) OCR Reader  — extracts text from scanned/image-based PDFs
  B) Visual Schedule Generator — creates a medication schedule graphic

Uses: pytesseract (OCR), Pillow (image), matplotlib (charts)
"""

import io
import os
import tempfile
from datetime import datetime

# ── A) OCR Reader ────────────────────────────────────────────────────────────

def _clean_ocr_text(raw_text: str, min_confidence: int = 60) -> str:
    """
    Post-process raw OCR output to reduce noise before sending to the LLM.

    Cleaning steps:
      1. Remove lines that are mostly non-alphanumeric (OCR artifacts)
      2. Collapse excessive whitespace
      3. Strip very short garbage lines (< 3 chars)
    """
    import re

    cleaned_lines = []
    for line in raw_text.split("\n"):
        stripped = line.strip()
        if not stripped:
            cleaned_lines.append("")
            continue
        # Skip lines shorter than 3 characters (likely OCR noise)
        if len(stripped) < 3:
            continue
        # Skip lines where less than 40% of characters are alphanumeric
        alnum_ratio = sum(c.isalnum() or c.isspace() for c in stripped) / len(stripped)
        if alnum_ratio < 0.4:
            continue
        # Collapse multiple spaces into one
        cleaned_lines.append(re.sub(r" {2,}", " ", stripped))

    # Collapse 3+ blank lines into 2
    text = "\n".join(cleaned_lines)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _ocr_with_confidence(img, min_confidence: int = 60) -> tuple[str, float]:
    """
    OCR an image using pytesseract with confidence scoring.
    Returns (text, avg_confidence) where avg_confidence is the mean
    word-level confidence (0-100). Low confidence suggests noisy input.
    """
    import pytesseract

    # Get word-level confidence data
    try:
        data = pytesseract.image_to_data(img, output_type=pytesseract.Output.DICT)
        confidences = [int(c) for c in data["conf"] if int(c) > 0]
        avg_conf = sum(confidences) / len(confidences) if confidences else 0.0

        # Filter to words above the confidence threshold
        high_conf_words = [
            data["text"][i] for i in range(len(data["text"]))
            if int(data["conf"][i]) >= min_confidence and data["text"][i].strip()
        ]
    except Exception:
        # Fallback to standard OCR if confidence extraction fails
        text = pytesseract.image_to_string(img, lang="eng")
        return text, 0.0

    # Still use full image_to_string for layout preservation,
    # but use confidence stats for quality reporting
    text = pytesseract.image_to_string(img, lang="eng")
    return text, avg_conf


def extract_text_ocr(pdf_bytes: bytes) -> str:
    """
    Extract text from a scanned/image-based PDF using Tesseract OCR.
    Falls back gracefully if Tesseract is not installed.

    Pipeline: PDF → page images → OCR with confidence scoring → clean → text

    Post-processing:
      - Confidence scoring per page (flags low-quality scans)
      - Noise removal (artifact lines, garbage characters)
      - Whitespace normalization
    """
    try:
        import pytesseract
        from PIL import Image
        import pypdf
    except ImportError as e:
        return f"[OCR unavailable: {e}. Install pytesseract and Pillow.]"

    texts = []
    page_confidences = []

    try:
        # Try pdf2image first (better quality for scanned PDFs)
        from pdf2image import convert_from_bytes
        images = convert_from_bytes(pdf_bytes, dpi=300)
        for i, img in enumerate(images):
            page_text, conf = _ocr_with_confidence(img)
            page_confidences.append(conf)
            if page_text.strip():
                cleaned = _clean_ocr_text(page_text)
                if cleaned:
                    header = f"--- Page {i+1} (OCR confidence: {conf:.0f}%) ---"
                    texts.append(f"{header}\n{cleaned}")
    except ImportError:
        # Fallback: use pypdf to extract images from each page
        reader = pypdf.PdfReader(io.BytesIO(pdf_bytes))
        for page_num, page in enumerate(reader.pages):
            # Try text extraction first
            text = page.extract_text()
            if text and text.strip():
                texts.append(f"--- Page {page_num+1} ---\n{text.strip()}")
                page_confidences.append(100.0)
                continue

            # If no text, try to extract images and OCR them
            for img_key in page.images:
                try:
                    img_data = img_key.data
                    img = Image.open(io.BytesIO(img_data))
                    ocr_text, conf = _ocr_with_confidence(img)
                    page_confidences.append(conf)
                    if ocr_text.strip():
                        cleaned = _clean_ocr_text(ocr_text)
                        if cleaned:
                            header = f"--- Page {page_num+1} (OCR confidence: {conf:.0f}%) ---"
                            texts.append(f"{header}\n{cleaned}")
                except Exception:
                    continue
    except Exception as e:
        return f"[OCR error: {e}]"

    # Add quality warning if average confidence is low
    result = "\n\n".join(texts) if texts else ""
    if page_confidences:
        avg_conf = sum(page_confidences) / len(page_confidences)
        if avg_conf < 50 and result:
            result = (
                f"[⚠️ OCR QUALITY WARNING: Average confidence {avg_conf:.0f}% — "
                f"some text may be inaccurate. Please verify critical details.]\n\n"
                + result
            )
    return result


def is_scanned_pdf(pdf_bytes: bytes) -> bool:
    """
    Detect if a PDF is scanned (image-based) vs text-based.
    Returns True if less than 50 chars of text are extractable.
    """
    try:
        import pypdf
        reader = pypdf.PdfReader(io.BytesIO(pdf_bytes))
        total_text = ""
        for page in reader.pages[:3]:  # Check first 3 pages
            text = page.extract_text() or ""
            total_text += text
        return len(total_text.strip()) < 50
    except Exception:
        return False


# ── B) Visual Medication Schedule ────────────────────────────────────────────

# Time-of-day assignment rules
TIME_RULES = {
    "morning":   "Morning\n(7-8 AM)",
    "afternoon": "Afternoon\n(12-1 PM)",
    "evening":   "Evening\n(6-7 PM)",
    "bedtime":   "Bedtime\n(9-10 PM)",
}


def _assign_times(medication: dict) -> list[str]:
    """
    Assign time-of-day slots based on frequency text.
    Returns list of time slot keys.
    """
    freq = medication.get("frequency", "").lower()
    notes = medication.get("notes", "").lower()
    combined = freq + " " + notes

    if "twice daily" in combined or "two times" in combined:
        if "with meals" in combined or "with food" in combined:
            return ["morning", "evening"]
        return ["morning", "evening"]
    elif "three times" in combined:
        return ["morning", "afternoon", "evening"]
    elif "bedtime" in combined or "at night" in combined:
        return ["bedtime"]
    elif "morning" in combined:
        return ["morning"]
    elif "before breakfast" in combined:
        return ["morning"]
    elif "once daily" in combined:
        return ["morning"]
    elif "every 4" in combined or "every 6" in combined:
        return ["morning", "afternoon", "evening"]
    else:
        return ["morning"]


def generate_medication_schedule(medications: list[dict],
                                  diagnosis: str = "",
                                  save_path: str = None) -> str:
    """
    Generate a visual medication schedule as a PNG image.
    Shows a grid: rows = medications, columns = time of day.
    Color-coded by food requirements.

    Returns the file path of the generated image.
    """
    import matplotlib
    matplotlib.use("Agg")  # Non-interactive backend
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    from matplotlib.patches import FancyBboxPatch
    import numpy as np

    if not medications:
        return None

    # Time slots
    time_slots = ["morning", "afternoon", "evening", "bedtime"]
    time_labels = [TIME_RULES[t] for t in time_slots]

    # Build the schedule grid
    med_names = []
    med_doses = []
    schedule  = []  # list of lists: 1 = take, 0 = skip
    food_flags = []

    for med in medications:
        name = med["name"]
        dose = med.get("dose", "")
        times = _assign_times(med)
        row = [1 if t in times else 0 for t in time_slots]
        med_names.append(name)
        med_doses.append(dose)
        schedule.append(row)
        food_flags.append(med.get("with_food", False))

    n_meds = len(med_names)
    n_times = len(time_slots)

    # ── Create the figure ────────────────────────────────────────────────
    fig_height = max(4, 1.2 * n_meds + 2.5)
    fig, ax = plt.subplots(figsize=(10, fig_height))

    # Colors
    bg_color      = "#f8fafc"
    header_color  = "#1e40af"
    pill_color    = "#3b82f6"
    food_color    = "#f59e0b"
    empty_color   = "#e2e8f0"
    text_color    = "#1e293b"
    white         = "#ffffff"

    fig.patch.set_facecolor(bg_color)
    ax.set_facecolor(bg_color)

    cell_w = 1.0
    cell_h = 0.8
    left_margin = 3.5
    top_margin = 1.5

    # Header row
    for j, label in enumerate(time_labels):
        x = left_margin + j * cell_w
        y = top_margin
        ax.add_patch(FancyBboxPatch(
            (x + 0.05, y + 0.05), cell_w - 0.1, cell_h - 0.1,
            boxstyle="round,pad=0.05", facecolor=header_color,
            edgecolor="none"
        ))
        ax.text(x + cell_w / 2, y + cell_h / 2, label,
                ha="center", va="center", fontsize=7,
                color=white, fontweight="bold")

    # Medication rows
    for i in range(n_meds):
        y = top_margin - (i + 1) * cell_h

        # Medication name + dose (left column)
        label = f"{med_names[i]}\n{med_doses[i]}"
        if food_flags[i]:
            label += " 🍽️"
        ax.text(left_margin - 0.2, y + cell_h / 2, label,
                ha="right", va="center", fontsize=8,
                color=text_color, fontweight="bold")

        # Time slot cells
        for j in range(n_times):
            x = left_margin + j * cell_w
            if schedule[i][j]:
                color = food_color if food_flags[i] else pill_color
                ax.add_patch(FancyBboxPatch(
                    (x + 0.05, y + 0.05), cell_w - 0.1, cell_h - 0.1,
                    boxstyle="round,pad=0.05", facecolor=color,
                    edgecolor="none", alpha=0.9
                ))
                ax.text(x + cell_w / 2, y + cell_h / 2, "💊",
                        ha="center", va="center", fontsize=14)
            else:
                ax.add_patch(FancyBboxPatch(
                    (x + 0.05, y + 0.05), cell_w - 0.1, cell_h - 0.1,
                    boxstyle="round,pad=0.05", facecolor=empty_color,
                    edgecolor="none", alpha=0.5
                ))
                ax.text(x + cell_w / 2, y + cell_h / 2, "—",
                        ha="center", va="center", fontsize=10,
                        color="#94a3b8")

    # Title
    title = "📋 Daily Medication Schedule"
    if diagnosis:
        title += f"  •  {diagnosis}"
    ax.text(left_margin + (n_times * cell_w) / 2, top_margin + cell_h + 0.5,
            title, ha="center", va="center", fontsize=14,
            color=header_color, fontweight="bold")

    # Legend
    legend_y = top_margin - (n_meds + 1) * cell_h - 0.3
    legend_items = [
        (pill_color, "Take medication"),
        (food_color, "Take WITH food  🍽️"),
        (empty_color, "No dose at this time"),
    ]
    for k, (color, label) in enumerate(legend_items):
        lx = left_margin + k * 2.2
        ax.add_patch(FancyBboxPatch(
            (lx, legend_y), 0.3, 0.3,
            boxstyle="round,pad=0.02", facecolor=color,
            edgecolor="none", alpha=0.9
        ))
        ax.text(lx + 0.4, legend_y + 0.15, label,
                ha="left", va="center", fontsize=7, color=text_color)

    # Date footer
    ax.text(left_margin + (n_times * cell_w) / 2, legend_y - 0.5,
            f"Generated {datetime.now().strftime('%B %d, %Y')}  •  ClearDischarge",
            ha="center", va="center", fontsize=7, color="#94a3b8")

    # Clean up axes
    ax.set_xlim(-0.5, left_margin + n_times * cell_w + 0.5)
    ax.set_ylim(legend_y - 0.8, top_margin + cell_h + 1.0)
    ax.axis("off")
    plt.tight_layout()

    # Save PNG
    if save_path is None:
        save_path = os.path.join(tempfile.gettempdir(), "medication_schedule.png")
    plt.savefig(save_path, dpi=200, bbox_inches="tight",
                facecolor=bg_color, edgecolor="none")

    # Also save a printable PDF version alongside the PNG
    pdf_path = save_path.replace(".png", ".pdf")
    try:
        plt.savefig(pdf_path, bbox_inches="tight",
                    facecolor=bg_color, edgecolor="none")
    except Exception:
        pdf_path = None

    plt.close(fig)

    return save_path, pdf_path


def get_alarm_suggestions(medications: list[dict]) -> list[dict]:
    """
    Generate suggested alarm times based on medication schedule.
    Helps patients set phone reminders for each dose.

    Returns a list of {"time": "7:00 AM", "medications": ["Drug A", "Drug B"]}.
    """
    ALARM_TIMES = {
        "morning":   "7:00 AM",
        "afternoon": "12:30 PM",
        "evening":   "6:30 PM",
        "bedtime":   "9:30 PM",
    }

    # Group medications by time slot
    time_groups = {}
    for med in medications:
        times = _assign_times(med)
        for t in times:
            if t not in time_groups:
                time_groups[t] = []
            label = f"{med['name']} {med.get('dose', '')}"
            if med.get("with_food"):
                label += " (with food)"
            time_groups[t].append(label)

    # Build alarm list sorted by time of day
    slot_order = ["morning", "afternoon", "evening", "bedtime"]
    alarms = []
    for slot in slot_order:
        if slot in time_groups:
            alarms.append({
                "time":        ALARM_TIMES[slot],
                "slot":        slot.title(),
                "medications": time_groups[slot]
            })

    return alarms


# ── Test block ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    # Test with sample medications
    sample_meds = [
        {"name": "Furosemide (Lasix)", "dose": "40mg",  "frequency": "once daily in the morning", "with_food": False},
        {"name": "Lisinopril",         "dose": "10mg",  "frequency": "once daily",                "with_food": True},
        {"name": "Carvedilol",         "dose": "6.25mg","frequency": "twice daily with meals",    "with_food": True},
        {"name": "Warfarin",           "dose": "5mg",   "frequency": "once daily",                "with_food": False},
        {"name": "Potassium Chloride", "dose": "20mEq", "frequency": "twice daily with food",     "with_food": True},
        {"name": "Aspirin",            "dose": "81mg",  "frequency": "once daily",                "with_food": False},
    ]

    path, pdf_path = generate_medication_schedule(
        sample_meds,
        diagnosis="Congestive Heart Failure",
        save_path="medication_schedule.png"
    )
    print(f"✅ Medication schedule saved to: {path}")
    if pdf_path:
        print(f"✅ Printable PDF saved to: {pdf_path}")

    # Test alarm suggestions
    alarms = get_alarm_suggestions(sample_meds)
    print(f"\n⏰ Suggested Alarms ({len(alarms)} reminders):")
    for a in alarms:
        print(f"   {a['time']} ({a['slot']}): {', '.join(a['medications'])}")

    # Test OCR detection
    print("\n🔍 OCR module loaded successfully.")
    print("   Use is_scanned_pdf(bytes) to detect scanned PDFs")
    print("   Use extract_text_ocr(bytes) to OCR scanned PDFs")
