"""
ClearDischarge — Component 4: Synthetic Data Generation
═══════════════════════════════════════════════════════
Generates diverse, realistic discharge summaries with
ground truth annotations for evaluation and testing.

Strategy:
- 8 diagnosis categories covering cardiac, respiratory,
  surgical, endocrine, neurological, renal, GI, and orthopedic
- 3 complexity tiers (simple/moderate/complex) based on med count
- Edge cases: missing fields, abbreviations, varied formatting
- Auto-generated ground truth for recall evaluation

Uses: Claude API for generation, structured JSON output
"""

import os
import json
import random
from groq import Groq
from dotenv import load_dotenv

load_dotenv()
client = Groq(api_key=os.getenv("GROQ_API_KEY"))
MODEL = "llama-3.3-70b-versatile"

# ── Diversity dimensions ─────────────────────────────────────────────────────
DIAGNOSIS_CATEGORIES = [
    {
        "category": "cardiac",
        "diagnoses": [
            "Congestive Heart Failure, acute exacerbation",
            "Acute Myocardial Infarction (STEMI)",
            "Atrial Fibrillation with rapid ventricular response",
            "Unstable Angina"
        ]
    },
    {
        "category": "respiratory",
        "diagnoses": [
            "Community-acquired pneumonia",
            "COPD exacerbation",
            "Pulmonary embolism",
            "Acute asthma exacerbation"
        ]
    },
    {
        "category": "surgical",
        "diagnoses": [
            "Right total hip arthroplasty",
            "Left total knee replacement",
            "Laparoscopic cholecystectomy",
            "Appendectomy (open)"
        ]
    },
    {
        "category": "endocrine",
        "diagnoses": [
            "Type 2 Diabetes Mellitus, poorly controlled",
            "Diabetic ketoacidosis (DKA)",
            "Hyperthyroidism, Graves disease",
            "Adrenal insufficiency"
        ]
    },
    {
        "category": "neurological",
        "diagnoses": [
            "Ischemic stroke, left MCA territory",
            "Transient ischemic attack (TIA)",
            "Seizure disorder, new onset",
            "Bacterial meningitis"
        ]
    },
    {
        "category": "renal",
        "diagnoses": [
            "Acute kidney injury, stage 2",
            "Chronic kidney disease, stage 3 exacerbation",
            "Nephrolithiasis with ureteral obstruction",
            "Urinary tract infection with sepsis"
        ]
    },
    {
        "category": "gastrointestinal",
        "diagnoses": [
            "Upper GI bleed, peptic ulcer",
            "Acute pancreatitis",
            "Diverticulitis, uncomplicated",
            "Clostridioides difficile colitis"
        ]
    },
    {
        "category": "orthopedic",
        "diagnoses": [
            "Right distal radius fracture, ORIF",
            "Lumbar spinal stenosis, post-laminectomy",
            "Left ankle fracture, cast immobilization",
            "Rotator cuff repair"
        ]
    }
]

COMPLEXITY_TIERS = {
    "simple":   {"med_range": (2, 4),  "restriction_range": (1, 3), "flag_range": (2, 4)},
    "moderate": {"med_range": (4, 7),  "restriction_range": (3, 5), "flag_range": (3, 5)},
    "complex":  {"med_range": (7, 12), "restriction_range": (4, 7), "flag_range": (5, 8)},
}

EDGE_CASE_STYLES = [
    "standard",           # Normal formatting
    "abbreviations",      # Uses medical abbreviations (PO, BID, PRN, etc.)
    "minimal",            # Missing some sections (no restrictions, or no follow-up)
    "narrative",          # Written in paragraph form instead of lists
    "mixed_formatting",   # Inconsistent formatting throughout
]

SYSTEM_PROMPT = """You are a medical simulation specialist creating realistic hospital discharge summaries for testing a patient education AI system.

Your ONLY output must be a valid JSON object with exactly these fields:
{
  "discharge_text": "The full discharge summary text as a string",
  "ground_truth": {
    "medications": ["List of medication names"],
    "restrictions": ["List of restriction descriptions"],
    "red_flags": ["List of red flag symptoms"]
  }
}

Rules:
1. The discharge summary must be medically realistic and internally consistent.
2. ground_truth.medications must list ONLY the generic drug names mentioned in the text.
3. ground_truth.restrictions must capture EVERY restriction mentioned.
4. ground_truth.red_flags must capture EVERY return-to-ER symptom.
5. Return ONLY the JSON — no markdown, no explanation, no code fences."""


def generate_case(category: str = None, complexity: str = None,
                  style: str = None, seed: int = None) -> dict:
    """
    Generate a single synthetic discharge summary with ground truth.

    Args:
        category:   diagnosis category (random if None)
        complexity: "simple", "moderate", or "complex" (random if None)
        style:      formatting style (random if None)
        seed:       random seed for reproducibility
    """
    if seed is not None:
        random.seed(seed)

    # Select parameters
    if category is None:
        cat = random.choice(DIAGNOSIS_CATEGORIES)
    else:
        cat = next((c for c in DIAGNOSIS_CATEGORIES if c["category"] == category),
                    random.choice(DIAGNOSIS_CATEGORIES))

    diagnosis  = random.choice(cat["diagnoses"])
    complexity = complexity or random.choice(list(COMPLEXITY_TIERS.keys()))
    style      = style or random.choice(EDGE_CASE_STYLES)
    tier       = COMPLEXITY_TIERS[complexity]

    n_meds         = random.randint(*tier["med_range"])
    n_restrictions = random.randint(*tier["restriction_range"])
    n_flags        = random.randint(*tier["flag_range"])

    prompt = (
        f"Generate a discharge summary for: {diagnosis}\n\n"
        f"Requirements:\n"
        f"- Include exactly {n_meds} medications with dose and frequency\n"
        f"- Include exactly {n_restrictions} activity/diet restrictions\n"
        f"- Include exactly {n_flags} return-to-ER red flag symptoms\n"
        f"- Include 1-3 follow-up appointments\n"
        f"- Formatting style: {style}\n"
    )

    if style == "abbreviations":
        prompt += "- Use medical abbreviations freely (PO, BID, TID, PRN, q4h, etc.)\n"
    elif style == "minimal":
        prompt += "- Omit the restrictions section entirely (leave it out of the text)\n"
    elif style == "narrative":
        prompt += "- Write as flowing paragraphs, not bulleted lists\n"
    elif style == "mixed_formatting":
        prompt += "- Mix bulleted lists, numbered lists, and paragraph style randomly\n"

    prompt += "\nReturn the JSON object now:"

    msg = client.chat.completions.create(
        model=MODEL,
        max_tokens=2048,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": prompt}
        ]
    )

    raw = msg.choices[0].message.content.strip()
    if raw.startswith("```"):
        raw = raw.split("```")[1]
        if raw.startswith("json"):
            raw = raw[4:]
    data = json.loads(raw.strip())

    # Add metadata
    data["metadata"] = {
        "category":   cat["category"],
        "diagnosis":  diagnosis,
        "complexity": complexity,
        "style":      style,
        "n_meds":     n_meds,
    }

    return data


def generate_test_suite(n_cases: int = 20, balanced: bool = True,
                         save_path: str = "synthetic_cases.json") -> list[dict]:
    """
    Generate a diverse test suite of synthetic discharge summaries.

    If balanced=True, distributes cases across categories and complexities.
    Tracks diversity metrics and edge case coverage.
    """
    cases = []
    categories  = [c["category"] for c in DIAGNOSIS_CATEGORIES]
    complexities = list(COMPLEXITY_TIERS.keys())
    styles       = EDGE_CASE_STYLES

    if balanced:
        # Round-robin across categories
        combos = []
        for cat in categories:
            for comp in complexities:
                combos.append((cat, comp))
        random.shuffle(combos)

        for i in range(n_cases):
            cat, comp = combos[i % len(combos)]
            style = styles[i % len(styles)]
            print(f"  [{i+1}/{n_cases}] Generating: {cat} / {comp} / {style}")
            try:
                case = generate_case(category=cat, complexity=comp,
                                     style=style, seed=42 + i)
                case["id"] = f"synth_{i+1:03d}"
                cases.append(case)
            except Exception as e:
                print(f"  ⚠️  Failed: {e}")
    else:
        for i in range(n_cases):
            print(f"  [{i+1}/{n_cases}] Generating random case...")
            try:
                case = generate_case(seed=42 + i)
                case["id"] = f"synth_{i+1:03d}"
                cases.append(case)
            except Exception as e:
                print(f"  ⚠️  Failed: {e}")

    # Save
    with open(save_path, "w") as f:
        json.dump(cases, f, indent=2)

    # Diversity report
    print(f"\n{'═'*60}")
    print(f"  SYNTHETIC DATA GENERATION REPORT")
    print(f"{'═'*60}")
    print(f"  Total cases generated:  {len(cases)}")
    print(f"  Categories covered:     {len(set(c['metadata']['category'] for c in cases))}/{len(categories)}")
    print(f"  Complexity distribution:")
    for comp in complexities:
        count = sum(1 for c in cases if c["metadata"]["complexity"] == comp)
        print(f"    {comp:>10}: {count}")
    print(f"  Style distribution:")
    for style in styles:
        count = sum(1 for c in cases if c["metadata"]["style"] == style)
        print(f"    {style:>18}: {count}")
    avg_meds = sum(c["metadata"]["n_meds"] for c in cases) / len(cases) if cases else 0
    print(f"  Avg medications/case:   {avg_meds:.1f}")
    print(f"  Saved to: {save_path}")
    print(f"{'═'*60}")

    return cases


# ── Built-in sample cases (for offline use) ──────────────────────────────────
BUILTIN_SAMPLES = [
    {
        "id": "sample_001",
        "discharge_text": """
        DISCHARGE SUMMARY — Congestive Heart Failure
        Primary Diagnosis: CHF acute exacerbation
        Medications: Furosemide 40mg once daily, Lisinopril 10mg once daily with food,
        Carvedilol 6.25mg twice daily with meals, Warfarin 5mg once daily,
        Potassium Chloride 20mEq twice daily with food, Aspirin 81mg once daily.
        Restrictions: No strenuous activity 2 weeks, fluid restriction 1.5L/day,
        low-sodium diet less than 2g/day, daily weight monitoring.
        Return to ER if: weight gain over 2 lbs/day, shortness of breath,
        chest pain, worsening leg swelling, dizziness or fainting.
        Follow-up: PCP within 7 days, Cardiologist within 2 weeks,
        INR clinic within 3 days.
        """,
        "ground_truth": {
            "medications": ["Furosemide", "Lisinopril", "Carvedilol",
                            "Warfarin", "Potassium Chloride", "Aspirin"],
            "restrictions": ["no strenuous activity", "fluid restriction",
                             "low-sodium diet", "daily weight monitoring"],
            "red_flags":    ["weight gain", "shortness of breath",
                             "chest pain", "leg swelling", "dizziness"]
        },
        "metadata": {"category": "cardiac", "complexity": "moderate", "style": "standard", "n_meds": 6}
    },
    {
        "id": "sample_002",
        "discharge_text": """
        DISCHARGE SUMMARY — Type 2 Diabetes
        Diagnosis: Type 2 Diabetes Mellitus, poorly controlled
        Medications: Metformin 500mg twice daily with meals,
        Glipizide 5mg once daily before breakfast,
        Lisinopril 5mg once daily, Atorvastatin 40mg once at bedtime.
        Restrictions: Diabetic diet, no driving if blood sugar below 70 mg/dL,
        monitor blood sugar twice daily.
        Return to ER if: blood sugar above 400 or below 60,
        chest pain, severe abdominal pain, difficulty breathing.
        Follow-up: Endocrinologist within 1 week, PCP within 2 weeks.
        """,
        "ground_truth": {
            "medications": ["Metformin", "Glipizide", "Lisinopril", "Atorvastatin"],
            "restrictions": ["diabetic diet", "no driving if low blood sugar",
                             "monitor blood sugar twice daily"],
            "red_flags":    ["blood sugar above 400", "blood sugar below 60",
                             "chest pain", "abdominal pain", "difficulty breathing"]
        },
        "metadata": {"category": "endocrine", "complexity": "moderate", "style": "standard", "n_meds": 4}
    },
    {
        "id": "sample_003",
        "discharge_text": """
        DISCHARGE SUMMARY — Pneumonia
        Diagnosis: Community-acquired pneumonia, right lower lobe
        Medications: Azithromycin 250mg once daily for 5 days,
        Amoxicillin 500mg three times daily for 7 days,
        Albuterol inhaler 2 puffs every 4-6 hours as needed,
        Ibuprofen 400mg every 6 hours with food for fever or pain.
        Restrictions: Rest for 1 week, avoid smoking,
        drink plenty of fluids at least 8 glasses daily.
        Return to ER if: fever above 103F, difficulty breathing at rest,
        coughing up blood, chest pain when breathing.
        Follow-up: PCP within 1 week for repeat chest X-ray.
        """,
        "ground_truth": {
            "medications": ["Azithromycin", "Amoxicillin", "Albuterol", "Ibuprofen"],
            "restrictions": ["rest for 1 week", "avoid smoking", "drink plenty of fluids"],
            "red_flags":    ["fever above 103", "difficulty breathing",
                             "coughing up blood", "chest pain when breathing"]
        },
        "metadata": {"category": "respiratory", "complexity": "moderate", "style": "standard", "n_meds": 4}
    },
    {
        "id": "sample_004",
        "discharge_text": """
        DISCHARGE SUMMARY — Hip Replacement Surgery
        Procedure: Right total hip arthroplasty
        Medications: Oxycodone 5mg every 4-6 hours as needed for pain,
        Aspirin 325mg twice daily for blood clot prevention for 6 weeks,
        Omeprazole 20mg once daily to protect stomach,
        Enoxaparin 40mg subcutaneous injection once daily for 2 weeks.
        Restrictions: No bending hip beyond 90 degrees,
        no crossing legs, use walker at all times,
        no driving for 6 weeks, no stairs without PT approval.
        Return to ER if: sudden chest pain, coughing up blood,
        severe leg swelling, wound opening or discharge, fever above 101F.
        Follow-up: Orthopedic surgeon in 2 weeks, Physical therapy 3x/week.
        """,
        "ground_truth": {
            "medications": ["Oxycodone", "Aspirin", "Omeprazole", "Enoxaparin"],
            "restrictions": ["no bending hip beyond 90 degrees", "no crossing legs",
                             "use walker", "no driving 6 weeks"],
            "red_flags":    ["chest pain", "coughing up blood", "leg swelling",
                             "wound opening", "fever above 101"]
        },
        "metadata": {"category": "surgical", "complexity": "moderate", "style": "standard", "n_meds": 4}
    },
    {
        "id": "sample_005",
        "discharge_text": """
        DISCHARGE SUMMARY — Hypertensive Crisis
        Diagnosis: Hypertensive urgency, BP 195/115 on admission
        Medications: Amlodipine 10mg once daily,
        Metoprolol Succinate 50mg once daily,
        Hydrochlorothiazide 25mg once daily in morning,
        Potassium 20mEq once daily with food.
        Restrictions: Low-sodium diet less than 1500mg/day,
        no caffeine, no smoking, limit alcohol to 1 drink/day,
        home blood pressure monitoring twice daily.
        Return to ER if: BP reading above 180/110,
        severe headache, vision changes, chest pain, confusion.
        Follow-up: PCP within 3 days to recheck BP.
        """,
        "ground_truth": {
            "medications": ["Amlodipine", "Metoprolol Succinate",
                            "Hydrochlorothiazide", "Potassium"],
            "restrictions": ["low-sodium diet", "no caffeine", "no smoking",
                             "limit alcohol", "home BP monitoring"],
            "red_flags":    ["BP above 180/110", "severe headache",
                             "vision changes", "chest pain", "confusion"]
        },
        "metadata": {"category": "cardiac", "complexity": "moderate", "style": "standard", "n_meds": 4}
    }
]


# ── Test block ───────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--n", type=int, default=5,
                        help="Number of synthetic cases to generate")
    parser.add_argument("--builtin", action="store_true",
                        help="Show built-in samples instead of generating new ones")
    args = parser.parse_args()

    if args.builtin:
        print("Built-in sample cases:")
        for case in BUILTIN_SAMPLES:
            gt = case["ground_truth"]
            print(f"\n  {case['id']}: {case['metadata']['category']} / {case['metadata']['complexity']}")
            print(f"    Meds: {', '.join(gt['medications'])}")
            print(f"    Flags: {', '.join(gt['red_flags'][:3])}...")
    else:
        print(f"Generating {args.n} synthetic cases...\n")
        cases = generate_test_suite(n_cases=args.n, balanced=True)
